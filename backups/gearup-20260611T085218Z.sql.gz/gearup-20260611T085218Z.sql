--
-- PostgreSQL database dump
--

\restrict 9eC8r8aTv3Ak82bSaF5Szx6VrMlq7FF6HAoxz1ELiHpugDzMuBA2gX1DRXtO41O

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10 (Ubuntu 17.10-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."ActivityLog" DROP CONSTRAINT IF EXISTS activity_log_actor_id_fkey;
ALTER TABLE IF EXISTS ONLY public."WorkerLeave" DROP CONSTRAINT IF EXISTS "WorkerLeave_workerId_fkey";
ALTER TABLE IF EXISTS ONLY public."WorkerAssignment" DROP CONSTRAINT IF EXISTS "WorkerAssignment_workerId_fkey";
ALTER TABLE IF EXISTS ONLY public."WorkerAssignment" DROP CONSTRAINT IF EXISTS "WorkerAssignment_jobCardId_fkey";
ALTER TABLE IF EXISTS ONLY public."Vehicle" DROP CONSTRAINT IF EXISTS "Vehicle_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public."StockMovement" DROP CONSTRAINT IF EXISTS "StockMovement_inventoryItemId_fkey";
ALTER TABLE IF EXISTS ONLY public."ServiceRequest" DROP CONSTRAINT IF EXISTS "ServiceRequest_vehicleId_fkey";
ALTER TABLE IF EXISTS ONLY public."ServiceRequest" DROP CONSTRAINT IF EXISTS "ServiceRequest_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public."RolePermission" DROP CONSTRAINT IF EXISTS "RolePermission_roleId_fkey";
ALTER TABLE IF EXISTS ONLY public."RolePermission" DROP CONSTRAINT IF EXISTS "RolePermission_permissionId_fkey";
ALTER TABLE IF EXISTS ONLY public."Payment" DROP CONSTRAINT IF EXISTS "Payment_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public."Notification" DROP CONSTRAINT IF EXISTS "Notification_createdByAdminId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobCard" DROP CONSTRAINT IF EXISTS "JobCard_vehicleId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobCard" DROP CONSTRAINT IF EXISTS "JobCard_serviceRequestId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobCard" DROP CONSTRAINT IF EXISTS "JobCard_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobCard" DROP CONSTRAINT IF EXISTS "JobCard_appointmentId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobCardTask" DROP CONSTRAINT IF EXISTS "JobCardTask_jobCardId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobCardTask" DROP CONSTRAINT IF EXISTS "JobCardTask_assignedWorkerId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobCardPart" DROP CONSTRAINT IF EXISTS "JobCardPart_jobCardId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobCardPart" DROP CONSTRAINT IF EXISTS "JobCardPart_inventoryItemId_fkey";
ALTER TABLE IF EXISTS ONLY public."Invoice" DROP CONSTRAINT IF EXISTS "Invoice_vehicleId_fkey";
ALTER TABLE IF EXISTS ONLY public."Invoice" DROP CONSTRAINT IF EXISTS "Invoice_jobCardId_fkey";
ALTER TABLE IF EXISTS ONLY public."Invoice" DROP CONSTRAINT IF EXISTS "Invoice_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public."Invoice" DROP CONSTRAINT IF EXISTS "Invoice_createdByAdminId_fkey";
ALTER TABLE IF EXISTS ONLY public."InvoiceLineItem" DROP CONSTRAINT IF EXISTS "InvoiceLineItem_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public."InventoryItem" DROP CONSTRAINT IF EXISTS "InventoryItem_supplierId_fkey";
ALTER TABLE IF EXISTS ONLY public."InventoryItem" DROP CONSTRAINT IF EXISTS "InventoryItem_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public."Expense" DROP CONSTRAINT IF EXISTS "Expense_createdByAdminId_fkey";
ALTER TABLE IF EXISTS ONLY public."Expense" DROP CONSTRAINT IF EXISTS "Expense_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public."Appointment" DROP CONSTRAINT IF EXISTS "Appointment_vehicleId_fkey";
ALTER TABLE IF EXISTS ONLY public."Appointment" DROP CONSTRAINT IF EXISTS "Appointment_serviceRequestId_fkey";
ALTER TABLE IF EXISTS ONLY public."Appointment" DROP CONSTRAINT IF EXISTS "Appointment_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public."Appointment" DROP CONSTRAINT IF EXISTS "Appointment_confirmedByAdminId_fkey";
ALTER TABLE IF EXISTS ONLY public."Appointment" DROP CONSTRAINT IF EXISTS "Appointment_assignedWorkerId_fkey";
ALTER TABLE IF EXISTS ONLY public."AmcServiceUsage" DROP CONSTRAINT IF EXISTS "AmcServiceUsage_jobCardId_fkey";
ALTER TABLE IF EXISTS ONLY public."AmcServiceUsage" DROP CONSTRAINT IF EXISTS "AmcServiceUsage_amcContractId_fkey";
ALTER TABLE IF EXISTS ONLY public."AmcContract" DROP CONSTRAINT IF EXISTS "AmcContract_vehicleId_fkey";
ALTER TABLE IF EXISTS ONLY public."AmcContract" DROP CONSTRAINT IF EXISTS "AmcContract_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public."AmcContract" DROP CONSTRAINT IF EXISTS "AmcContract_amcPlanId_fkey";
ALTER TABLE IF EXISTS ONLY public."AdminUserRole" DROP CONSTRAINT IF EXISTS "AdminUserRole_roleId_fkey";
ALTER TABLE IF EXISTS ONLY public."AdminUserRole" DROP CONSTRAINT IF EXISTS "AdminUserRole_adminUserId_fkey";
DROP INDEX IF EXISTS public."Worker_workerCode_key";
DROP INDEX IF EXISTS public."Worker_status_idx";
DROP INDEX IF EXISTS public."WorkerLeave_workerId_idx";
DROP INDEX IF EXISTS public."WorkerLeave_status_idx";
DROP INDEX IF EXISTS public."WorkerAssignment_workerId_idx";
DROP INDEX IF EXISTS public."WorkerAssignment_jobCardId_workerId_key";
DROP INDEX IF EXISTS public."WorkerAssignment_jobCardId_idx";
DROP INDEX IF EXISTS public."Vehicle_customerId_idx";
DROP INDEX IF EXISTS public."StockMovement_movementType_idx";
DROP INDEX IF EXISTS public."StockMovement_inventoryItemId_idx";
DROP INDEX IF EXISTS public."Setting_key_key";
DROP INDEX IF EXISTS public."ServiceRequest_vehicleId_idx";
DROP INDEX IF EXISTS public."ServiceRequest_status_idx";
DROP INDEX IF EXISTS public."ServiceRequest_referenceId_key";
DROP INDEX IF EXISTS public."ServiceRequest_customerId_idx";
DROP INDEX IF EXISTS public."Role_key_key";
DROP INDEX IF EXISTS public."RolePermission_roleId_permissionId_key";
DROP INDEX IF EXISTS public."Permission_key_key";
DROP INDEX IF EXISTS public."Payment_receivedByAdminId_idx";
DROP INDEX IF EXISTS public."Payment_paymentDate_idx";
DROP INDEX IF EXISTS public."Payment_invoiceId_idx";
DROP INDEX IF EXISTS public."Notification_sendStatus_idx";
DROP INDEX IF EXISTS public."Notification_scheduledFor_idx";
DROP INDEX IF EXISTS public."Notification_eventType_idx";
DROP INDEX IF EXISTS public."NotificationTemplate_templateKey_key";
DROP INDEX IF EXISTS public."JobCard_vehicleId_status_idx";
DROP INDEX IF EXISTS public."JobCard_vehicleId_idx";
DROP INDEX IF EXISTS public."JobCard_status_idx";
DROP INDEX IF EXISTS public."JobCard_serviceRequestId_idx";
DROP INDEX IF EXISTS public."JobCard_jobCardNumber_key";
DROP INDEX IF EXISTS public."JobCard_estimateToken_key";
DROP INDEX IF EXISTS public."JobCard_customerId_status_idx";
DROP INDEX IF EXISTS public."JobCard_customerId_idx";
DROP INDEX IF EXISTS public."JobCard_appointmentId_idx";
DROP INDEX IF EXISTS public."JobCardTask_jobCardId_idx";
DROP INDEX IF EXISTS public."JobCardTask_assignedWorkerId_idx";
DROP INDEX IF EXISTS public."JobCardPart_jobCardId_inventoryItemId_key";
DROP INDEX IF EXISTS public."JobCardPart_jobCardId_idx";
DROP INDEX IF EXISTS public."JobCardPart_inventoryItemId_idx";
DROP INDEX IF EXISTS public."Invoice_vehicleId_idx";
DROP INDEX IF EXISTS public."Invoice_paymentStatus_idx";
DROP INDEX IF EXISTS public."Invoice_jobCardId_idx";
DROP INDEX IF EXISTS public."Invoice_invoiceNumber_key";
DROP INDEX IF EXISTS public."Invoice_invoiceDate_paymentStatus_idx";
DROP INDEX IF EXISTS public."Invoice_invoiceDate_idx";
DROP INDEX IF EXISTS public."Invoice_customerId_paymentStatus_idx";
DROP INDEX IF EXISTS public."Invoice_customerId_idx";
DROP INDEX IF EXISTS public."Invoice_createdByAdminId_idx";
DROP INDEX IF EXISTS public."Invoice_appointmentId_idx";
DROP INDEX IF EXISTS public."InvoiceLineItem_invoiceId_idx";
DROP INDEX IF EXISTS public."InventoryItem_supplierId_idx";
DROP INDEX IF EXISTS public."InventoryItem_sku_key";
DROP INDEX IF EXISTS public."InventoryItem_itemName_idx";
DROP INDEX IF EXISTS public."InventoryItem_categoryId_idx";
DROP INDEX IF EXISTS public."InventoryCategory_categoryName_key";
DROP INDEX IF EXISTS public."Holiday_holidayDate_idx";
DROP INDEX IF EXISTS public."Expense_expenseDate_idx";
DROP INDEX IF EXISTS public."Expense_createdByAdminId_idx";
DROP INDEX IF EXISTS public."Expense_categoryId_idx";
DROP INDEX IF EXISTS public."ExpenseCategory_categoryName_key";
DROP INDEX IF EXISTS public."Customer_email_idx";
DROP INDEX IF EXISTS public."BlockedSlot_blockDate_idx";
DROP INDEX IF EXISTS public."Appointment_vehicleId_idx";
DROP INDEX IF EXISTS public."Appointment_status_idx";
DROP INDEX IF EXISTS public."Appointment_serviceRequestId_key";
DROP INDEX IF EXISTS public."Appointment_referenceId_key";
DROP INDEX IF EXISTS public."Appointment_customerId_idx";
DROP INDEX IF EXISTS public."Appointment_confirmedByAdminId_idx";
DROP INDEX IF EXISTS public."Appointment_assignedWorkerId_idx";
DROP INDEX IF EXISTS public."Appointment_appointmentDate_idx";
DROP INDEX IF EXISTS public."AmcServiceUsage_jobCardId_idx";
DROP INDEX IF EXISTS public."AmcServiceUsage_amcContractId_jobCardId_key";
DROP INDEX IF EXISTS public."AmcServiceUsage_amcContractId_idx";
DROP INDEX IF EXISTS public."AmcContract_vehicleId_idx";
DROP INDEX IF EXISTS public."AmcContract_status_idx";
DROP INDEX IF EXISTS public."AmcContract_customerId_idx";
DROP INDEX IF EXISTS public."AmcContract_contractNumber_key";
DROP INDEX IF EXISTS public."AmcContract_amcPlanId_idx";
DROP INDEX IF EXISTS public."AdminUser_email_key";
DROP INDEX IF EXISTS public."AdminUser_adminUserId_key";
DROP INDEX IF EXISTS public."AdminUserRole_adminUserId_roleId_key";
DROP INDEX IF EXISTS public."ActivityLog_entityType_entityId_idx";
DROP INDEX IF EXISTS public."ActivityLog_createdAt_idx";
DROP INDEX IF EXISTS public."ActivityLog_actorType_idx";
DROP INDEX IF EXISTS public."ActivityLog_action_idx";
ALTER TABLE IF EXISTS ONLY public."Worker" DROP CONSTRAINT IF EXISTS "Worker_pkey";
ALTER TABLE IF EXISTS ONLY public."WorkerLeave" DROP CONSTRAINT IF EXISTS "WorkerLeave_pkey";
ALTER TABLE IF EXISTS ONLY public."WorkerAssignment" DROP CONSTRAINT IF EXISTS "WorkerAssignment_pkey";
ALTER TABLE IF EXISTS ONLY public."Vehicle" DROP CONSTRAINT IF EXISTS "Vehicle_pkey";
ALTER TABLE IF EXISTS ONLY public."Supplier" DROP CONSTRAINT IF EXISTS "Supplier_pkey";
ALTER TABLE IF EXISTS ONLY public."StockMovement" DROP CONSTRAINT IF EXISTS "StockMovement_pkey";
ALTER TABLE IF EXISTS ONLY public."Setting" DROP CONSTRAINT IF EXISTS "Setting_pkey";
ALTER TABLE IF EXISTS ONLY public."ServiceRequest" DROP CONSTRAINT IF EXISTS "ServiceRequest_pkey";
ALTER TABLE IF EXISTS ONLY public."Role" DROP CONSTRAINT IF EXISTS "Role_pkey";
ALTER TABLE IF EXISTS ONLY public."RolePermission" DROP CONSTRAINT IF EXISTS "RolePermission_pkey";
ALTER TABLE IF EXISTS ONLY public."Permission" DROP CONSTRAINT IF EXISTS "Permission_pkey";
ALTER TABLE IF EXISTS ONLY public."Payment" DROP CONSTRAINT IF EXISTS "Payment_pkey";
ALTER TABLE IF EXISTS ONLY public."Notification" DROP CONSTRAINT IF EXISTS "Notification_pkey";
ALTER TABLE IF EXISTS ONLY public."NotificationTemplate" DROP CONSTRAINT IF EXISTS "NotificationTemplate_pkey";
ALTER TABLE IF EXISTS ONLY public."JobCard" DROP CONSTRAINT IF EXISTS "JobCard_pkey";
ALTER TABLE IF EXISTS ONLY public."JobCardTask" DROP CONSTRAINT IF EXISTS "JobCardTask_pkey";
ALTER TABLE IF EXISTS ONLY public."JobCardPart" DROP CONSTRAINT IF EXISTS "JobCardPart_pkey";
ALTER TABLE IF EXISTS ONLY public."Invoice" DROP CONSTRAINT IF EXISTS "Invoice_pkey";
ALTER TABLE IF EXISTS ONLY public."InvoiceLineItem" DROP CONSTRAINT IF EXISTS "InvoiceLineItem_pkey";
ALTER TABLE IF EXISTS ONLY public."InventoryItem" DROP CONSTRAINT IF EXISTS "InventoryItem_pkey";
ALTER TABLE IF EXISTS ONLY public."InventoryCategory" DROP CONSTRAINT IF EXISTS "InventoryCategory_pkey";
ALTER TABLE IF EXISTS ONLY public."Holiday" DROP CONSTRAINT IF EXISTS "Holiday_pkey";
ALTER TABLE IF EXISTS ONLY public."Expense" DROP CONSTRAINT IF EXISTS "Expense_pkey";
ALTER TABLE IF EXISTS ONLY public."ExpenseCategory" DROP CONSTRAINT IF EXISTS "ExpenseCategory_pkey";
ALTER TABLE IF EXISTS ONLY public."Customer" DROP CONSTRAINT IF EXISTS "Customer_pkey";
ALTER TABLE IF EXISTS ONLY public."BlockedSlot" DROP CONSTRAINT IF EXISTS "BlockedSlot_pkey";
ALTER TABLE IF EXISTS ONLY public."Appointment" DROP CONSTRAINT IF EXISTS "Appointment_pkey";
ALTER TABLE IF EXISTS ONLY public."AppointmentSlotRule" DROP CONSTRAINT IF EXISTS "AppointmentSlotRule_pkey";
ALTER TABLE IF EXISTS ONLY public."AmcServiceUsage" DROP CONSTRAINT IF EXISTS "AmcServiceUsage_pkey";
ALTER TABLE IF EXISTS ONLY public."AmcPlan" DROP CONSTRAINT IF EXISTS "AmcPlan_pkey";
ALTER TABLE IF EXISTS ONLY public."AmcContract" DROP CONSTRAINT IF EXISTS "AmcContract_pkey";
ALTER TABLE IF EXISTS ONLY public."AdminUser" DROP CONSTRAINT IF EXISTS "AdminUser_pkey";
ALTER TABLE IF EXISTS ONLY public."AdminUserRole" DROP CONSTRAINT IF EXISTS "AdminUserRole_pkey";
ALTER TABLE IF EXISTS ONLY public."ActivityLog" DROP CONSTRAINT IF EXISTS "ActivityLog_pkey";
DROP TABLE IF EXISTS public."WorkerLeave";
DROP TABLE IF EXISTS public."WorkerAssignment";
DROP TABLE IF EXISTS public."Worker";
DROP TABLE IF EXISTS public."Vehicle";
DROP TABLE IF EXISTS public."Supplier";
DROP TABLE IF EXISTS public."StockMovement";
DROP TABLE IF EXISTS public."Setting";
DROP TABLE IF EXISTS public."ServiceRequest";
DROP TABLE IF EXISTS public."RolePermission";
DROP TABLE IF EXISTS public."Role";
DROP TABLE IF EXISTS public."Permission";
DROP TABLE IF EXISTS public."Payment";
DROP TABLE IF EXISTS public."NotificationTemplate";
DROP TABLE IF EXISTS public."Notification";
DROP TABLE IF EXISTS public."JobCardTask";
DROP TABLE IF EXISTS public."JobCardPart";
DROP TABLE IF EXISTS public."JobCard";
DROP TABLE IF EXISTS public."InvoiceLineItem";
DROP TABLE IF EXISTS public."Invoice";
DROP TABLE IF EXISTS public."InventoryItem";
DROP TABLE IF EXISTS public."InventoryCategory";
DROP TABLE IF EXISTS public."Holiday";
DROP TABLE IF EXISTS public."ExpenseCategory";
DROP TABLE IF EXISTS public."Expense";
DROP TABLE IF EXISTS public."Customer";
DROP TABLE IF EXISTS public."BlockedSlot";
DROP TABLE IF EXISTS public."AppointmentSlotRule";
DROP TABLE IF EXISTS public."Appointment";
DROP TABLE IF EXISTS public."AmcServiceUsage";
DROP TABLE IF EXISTS public."AmcPlan";
DROP TABLE IF EXISTS public."AmcContract";
DROP TABLE IF EXISTS public."AdminUserRole";
DROP TABLE IF EXISTS public."AdminUser";
DROP TABLE IF EXISTS public."ActivityLog";
DROP TYPE IF EXISTS public."WorkerStatus";
DROP TYPE IF EXISTS public."VehicleType";
DROP TYPE IF EXISTS public."ServiceRequestStatus";
DROP TYPE IF EXISTS public."PaymentStatus";
DROP TYPE IF EXISTS public."PaymentMode";
DROP TYPE IF EXISTS public."NotificationStatus";
DROP TYPE IF EXISTS public."NotificationChannel";
DROP TYPE IF EXISTS public."LeaveStatus";
DROP TYPE IF EXISTS public."JobCardStatus";
DROP TYPE IF EXISTS public."InvoiceStatus";
DROP TYPE IF EXISTS public."InvoiceLineType";
DROP TYPE IF EXISTS public."InventoryMovementType";
DROP TYPE IF EXISTS public."HolidayType";
DROP TYPE IF EXISTS public."ApprovalStatus";
DROP TYPE IF EXISTS public."AppointmentStatus";
DROP TYPE IF EXISTS public."AmcContractStatus";
DROP TYPE IF EXISTS public."AdminUserStatus";
DROP TYPE IF EXISTS public."ActorType";
DROP SCHEMA IF EXISTS public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: ActorType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ActorType" AS ENUM (
    'ADMIN',
    'WORKER',
    'SYSTEM',
    'PUBLIC'
);


--
-- Name: AdminUserStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AdminUserStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'LOCKED'
);


--
-- Name: AmcContractStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AmcContractStatus" AS ENUM (
    'ACTIVE',
    'EXPIRED',
    'CANCELLED'
);


--
-- Name: AppointmentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AppointmentStatus" AS ENUM (
    'REQUESTED',
    'PENDING_REVIEW',
    'CONFIRMED',
    'RESCHEDULED',
    'CANCELLED',
    'NO_SHOW',
    'CHECKED_IN',
    'COMPLETED'
);


--
-- Name: ApprovalStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ApprovalStatus" AS ENUM (
    'NOT_REQUIRED',
    'PENDING',
    'APPROVED',
    'REJECTED'
);


--
-- Name: HolidayType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."HolidayType" AS ENUM (
    'PUBLIC_HOLIDAY',
    'WEEKLY_OFF',
    'BUSINESS_CLOSURE',
    'MAINTENANCE_SHUTDOWN',
    'CUSTOM_BLOCK'
);


--
-- Name: InventoryMovementType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InventoryMovementType" AS ENUM (
    'STOCK_IN',
    'STOCK_OUT',
    'ADJUSTMENT_INCREASE',
    'ADJUSTMENT_DECREASE',
    'RESERVED',
    'RELEASED',
    'CONSUMED',
    'RETURNED'
);


--
-- Name: InvoiceLineType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InvoiceLineType" AS ENUM (
    'PART',
    'LABOR',
    'SERVICE_CHARGE',
    'CUSTOM_CHARGE',
    'DISCOUNT_ADJUSTMENT',
    'AMC'
);


--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'DRAFT',
    'FINALIZED',
    'CANCELLED'
);


--
-- Name: JobCardStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."JobCardStatus" AS ENUM (
    'CREATED',
    'UNDER_INSPECTION',
    'ESTIMATE_PREPARED',
    'AWAITING_CUSTOMER_APPROVAL',
    'APPROVED',
    'REJECTED',
    'PARTS_PENDING',
    'WORK_IN_PROGRESS',
    'QUALITY_CHECK',
    'READY_FOR_DELIVERY',
    'DELIVERED',
    'CANCELLED',
    'CLOSED'
);


--
-- Name: LeaveStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."LeaveStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


--
-- Name: NotificationChannel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."NotificationChannel" AS ENUM (
    'WHATSAPP',
    'EMAIL'
);


--
-- Name: NotificationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."NotificationStatus" AS ENUM (
    'QUEUED',
    'PROCESSING',
    'SENT',
    'DELIVERED',
    'FAILED',
    'DEAD_LETTER'
);


--
-- Name: PaymentMode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentMode" AS ENUM (
    'CASH',
    'CARD',
    'UPI',
    'BANK_TRANSFER',
    'CHEQUE',
    'OTHER'
);


--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'UNPAID',
    'PARTIALLY_PAID',
    'PAID',
    'REFUNDED',
    'WAIVED'
);


--
-- Name: ServiceRequestStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ServiceRequestStatus" AS ENUM (
    'SUBMITTED',
    'UNDER_REVIEW',
    'APPOINTMENT_PENDING',
    'APPOINTMENT_CONFIRMED',
    'CONVERTED_TO_JOB',
    'CANCELLED',
    'CLOSED'
);


--
-- Name: VehicleType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."VehicleType" AS ENUM (
    'CAR',
    'BIKE',
    'SCOOTY',
    'OTHER'
);


--
-- Name: WorkerStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."WorkerStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'ON_LEAVE'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ActivityLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ActivityLog" (
    id text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text,
    action text NOT NULL,
    "previousValueJson" jsonb,
    "newValueJson" jsonb,
    "actorType" public."ActorType" NOT NULL,
    "actorId" text,
    "requestId" text,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AdminUser; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AdminUser" (
    id text NOT NULL,
    "adminUserId" text NOT NULL,
    "fullName" text NOT NULL,
    email text,
    phone text,
    "passwordHash" text NOT NULL,
    status public."AdminUserStatus" DEFAULT 'ACTIVE'::public."AdminUserStatus" NOT NULL,
    "failedLoginAttempts" integer DEFAULT 0 NOT NULL,
    "lockedUntil" timestamp(3) without time zone,
    "lastLoginAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AdminUserRole; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AdminUserRole" (
    id text NOT NULL,
    "adminUserId" text NOT NULL,
    "roleId" text NOT NULL
);


--
-- Name: AmcContract; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AmcContract" (
    id text NOT NULL,
    "contractNumber" text NOT NULL,
    "customerId" text NOT NULL,
    "vehicleId" text NOT NULL,
    "amcPlanId" text NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "totalServices" integer NOT NULL,
    "servicesUsed" integer DEFAULT 0 NOT NULL,
    "servicesRemaining" integer NOT NULL,
    "amountPaid" numeric(12,2) NOT NULL,
    "paymentMode" public."PaymentMode",
    "paymentDate" timestamp(3) without time zone,
    status public."AmcContractStatus" DEFAULT 'ACTIVE'::public."AmcContractStatus" NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AmcPlan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AmcPlan" (
    id text NOT NULL,
    "planName" text NOT NULL,
    description text,
    "vehicleType" public."VehicleType" NOT NULL,
    "ccRange" text,
    "durationMonths" integer NOT NULL,
    "totalServicesIncluded" integer NOT NULL,
    price numeric(12,2) NOT NULL,
    "coveredItems" jsonb,
    exclusions text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AmcServiceUsage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AmcServiceUsage" (
    id text NOT NULL,
    "amcContractId" text NOT NULL,
    "jobCardId" text NOT NULL,
    "serviceNumber" integer NOT NULL,
    "serviceDate" timestamp(3) without time zone NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Appointment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Appointment" (
    id text NOT NULL,
    "referenceId" text NOT NULL,
    "serviceRequestId" text,
    "customerId" text NOT NULL,
    "vehicleId" text NOT NULL,
    "appointmentDate" timestamp(3) without time zone NOT NULL,
    "slotStart" timestamp(3) without time zone NOT NULL,
    "slotEnd" timestamp(3) without time zone NOT NULL,
    status public."AppointmentStatus" DEFAULT 'REQUESTED'::public."AppointmentStatus" NOT NULL,
    "bookingSource" text NOT NULL,
    "confirmationMode" text,
    "confirmedByAdminId" text,
    "assignedWorkerId" text,
    "bayId" text,
    "rescheduleReason" text,
    "cancellationReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AppointmentSlotRule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AppointmentSlotRule" (
    id text NOT NULL,
    "dayOfWeek" integer NOT NULL,
    "openTime" text NOT NULL,
    "closeTime" text NOT NULL,
    "slotDurationMinutes" integer NOT NULL,
    "maxCapacity" integer NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: BlockedSlot; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BlockedSlot" (
    id text NOT NULL,
    "blockDate" timestamp(3) without time zone NOT NULL,
    "blockStartTime" timestamp(3) without time zone NOT NULL,
    "blockEndTime" timestamp(3) without time zone NOT NULL,
    "blockReason" text NOT NULL,
    "appliesToAll" boolean DEFAULT true NOT NULL,
    "workerId" text,
    "bayId" text,
    "createdByAdminId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Customer" (
    id text NOT NULL,
    "fullName" text NOT NULL,
    "phoneNumber" text NOT NULL,
    "alternatePhone" text,
    email text,
    "addressLine1" text,
    "addressLine2" text,
    city text,
    state text,
    "postalCode" text,
    notes text,
    source text,
    "archivedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Expense; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Expense" (
    id text NOT NULL,
    "expenseDate" timestamp(3) without time zone NOT NULL,
    "categoryId" text NOT NULL,
    title text NOT NULL,
    amount numeric(12,2) NOT NULL,
    "vendorName" text,
    "paymentMode" public."PaymentMode",
    "referenceNumber" text,
    notes text,
    "createdByAdminId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ExpenseCategory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ExpenseCategory" (
    id text NOT NULL,
    "categoryName" text NOT NULL,
    description text
);


--
-- Name: Holiday; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Holiday" (
    id text NOT NULL,
    "holidayName" text NOT NULL,
    "holidayDate" timestamp(3) without time zone NOT NULL,
    "holidayType" public."HolidayType" NOT NULL,
    "isFullDay" boolean DEFAULT true NOT NULL,
    "startTime" text,
    "endTime" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: InventoryCategory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."InventoryCategory" (
    id text NOT NULL,
    "categoryName" text NOT NULL,
    description text
);


--
-- Name: InventoryItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."InventoryItem" (
    id text NOT NULL,
    sku text NOT NULL,
    "itemName" text NOT NULL,
    "categoryId" text NOT NULL,
    "supplierId" text,
    brand text,
    description text,
    "compatibleVehicleTypes" text,
    unit text NOT NULL,
    "taxRate" numeric(5,2) DEFAULT 0 NOT NULL,
    "costPrice" numeric(12,2) DEFAULT 0 NOT NULL,
    mrp numeric(12,2),
    "sellingPrice" numeric(12,2) DEFAULT 0 NOT NULL,
    "discountPercent" numeric(5,2),
    "quantityInStock" numeric(12,2) DEFAULT 0 NOT NULL,
    "reservedQuantity" numeric(12,2) DEFAULT 0 NOT NULL,
    "reorderLevel" numeric(12,2),
    "reorderQuantity" numeric(12,2),
    "storageLocation" text,
    barcode text,
    "isActive" boolean DEFAULT true NOT NULL,
    "variablePrice" boolean DEFAULT false NOT NULL,
    "isBranded" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Invoice" (
    id text NOT NULL,
    "invoiceNumber" text NOT NULL,
    "customerId" text NOT NULL,
    "vehicleId" text,
    "jobCardId" text,
    "appointmentId" text,
    "invoiceDate" timestamp(3) without time zone NOT NULL,
    "dueDate" timestamp(3) without time zone,
    subtotal numeric(12,2) DEFAULT 0 NOT NULL,
    "discountType" text,
    "discountValue" numeric(12,2),
    "discountAmount" numeric(12,2) DEFAULT 0 NOT NULL,
    "taxTotal" numeric(12,2) DEFAULT 0 NOT NULL,
    "grandTotal" numeric(12,2) DEFAULT 0 NOT NULL,
    "amountPaid" numeric(12,2) DEFAULT 0 NOT NULL,
    "amountDue" numeric(12,2) DEFAULT 0 NOT NULL,
    "paymentStatus" public."PaymentStatus" DEFAULT 'UNPAID'::public."PaymentStatus" NOT NULL,
    "invoiceStatus" public."InvoiceStatus" DEFAULT 'DRAFT'::public."InvoiceStatus" NOT NULL,
    notes text,
    "finalizedAt" timestamp(3) without time zone,
    "createdByAdminId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: InvoiceLineItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."InvoiceLineItem" (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    "lineType" public."InvoiceLineType" NOT NULL,
    "referenceItemId" text,
    description text NOT NULL,
    quantity numeric(12,2) DEFAULT 1 NOT NULL,
    "unitPrice" numeric(12,2) DEFAULT 0 NOT NULL,
    "discountPercent" numeric(5,2) DEFAULT 0 NOT NULL,
    "taxRate" numeric(5,2) DEFAULT 0 NOT NULL,
    "taxAmount" numeric(12,2) DEFAULT 0 NOT NULL,
    "lineTotal" numeric(12,2) DEFAULT 0 NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL
);


--
-- Name: JobCard; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobCard" (
    id text NOT NULL,
    "jobCardNumber" text NOT NULL,
    "appointmentId" text,
    "serviceRequestId" text,
    "customerId" text NOT NULL,
    "vehicleId" text NOT NULL,
    "intakeDate" timestamp(3) without time zone NOT NULL,
    "odometerAtIntake" integer,
    "fuelIndicator" text,
    "estimatedDeliveryAt" timestamp(3) without time zone,
    "actualDeliveryAt" timestamp(3) without time zone,
    "issueSummary" text NOT NULL,
    "customerComplaints" text,
    "diagnosisNotes" text,
    "estimateNotes" text,
    "approvalStatus" public."ApprovalStatus" DEFAULT 'PENDING'::public."ApprovalStatus" NOT NULL,
    priority text,
    status public."JobCardStatus" DEFAULT 'CREATED'::public."JobCardStatus" NOT NULL,
    "assignedServiceManagerId" text,
    "estimatedPartsCost" numeric(12,2) DEFAULT 0 NOT NULL,
    "estimatedLaborCost" numeric(12,2) DEFAULT 0 NOT NULL,
    "estimatedOtherCost" numeric(12,2) DEFAULT 0 NOT NULL,
    "estimatedTotal" numeric(12,2) DEFAULT 0 NOT NULL,
    "finalPartsCost" numeric(12,2) DEFAULT 0 NOT NULL,
    "finalLaborCost" numeric(12,2) DEFAULT 0 NOT NULL,
    "finalOtherCost" numeric(12,2) DEFAULT 0 NOT NULL,
    "finalTotal" numeric(12,2) DEFAULT 0 NOT NULL,
    "customerVisibleNotes" text,
    "internalNotes" text,
    "estimateToken" text,
    "estimateTokenExpiresAt" timestamp(3) without time zone,
    "estimateRevision" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: JobCardPart; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobCardPart" (
    id text NOT NULL,
    "jobCardId" text NOT NULL,
    "inventoryItemId" text NOT NULL,
    "requiredQty" numeric(12,2) NOT NULL,
    "reservedQty" numeric(12,2) DEFAULT 0 NOT NULL,
    "consumedQty" numeric(12,2) DEFAULT 0 NOT NULL,
    "unitPrice" numeric(12,2) DEFAULT 0 NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: JobCardTask; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobCardTask" (
    id text NOT NULL,
    "jobCardId" text NOT NULL,
    "taskName" text NOT NULL,
    "taskDescription" text,
    status text NOT NULL,
    "assignedWorkerId" text,
    "estimatedMinutes" integer,
    "actualMinutes" integer,
    notes text,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Notification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    channel public."NotificationChannel" NOT NULL,
    "eventType" text NOT NULL,
    "templateKey" text NOT NULL,
    "recipientPhone" text,
    "recipientEmail" text,
    "payloadJson" jsonb NOT NULL,
    "sendStatus" public."NotificationStatus" DEFAULT 'QUEUED'::public."NotificationStatus" NOT NULL,
    "providerName" text,
    "providerMessageId" text,
    "errorMessage" text,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "scheduledFor" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "relatedEntityType" text,
    "relatedEntityId" text,
    "createdByAdminId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: NotificationTemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NotificationTemplate" (
    id text NOT NULL,
    channel public."NotificationChannel" NOT NULL,
    "eventType" text NOT NULL,
    "templateKey" text NOT NULL,
    subject text,
    "messageBody" text NOT NULL,
    "variableSchemaJson" jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    amount numeric(12,2) NOT NULL,
    "paymentMode" public."PaymentMode" NOT NULL,
    "paymentDate" timestamp(3) without time zone NOT NULL,
    "referenceNumber" text,
    notes text,
    "receivedByAdminId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Permission" (
    id text NOT NULL,
    key text NOT NULL,
    module text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Role" (
    id text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: RolePermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RolePermission" (
    id text NOT NULL,
    "roleId" text NOT NULL,
    "permissionId" text NOT NULL
);


--
-- Name: ServiceRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ServiceRequest" (
    id text NOT NULL,
    "referenceId" text NOT NULL,
    "customerId" text NOT NULL,
    "vehicleId" text NOT NULL,
    "serviceCategory" text NOT NULL,
    "issueDescription" text NOT NULL,
    "preferredDate" timestamp(3) without time zone,
    "preferredSlotLabel" text,
    urgency text,
    "pickupDropRequired" boolean DEFAULT false NOT NULL,
    notes text,
    status public."ServiceRequestStatus" DEFAULT 'SUBMITTED'::public."ServiceRequestStatus" NOT NULL,
    source text,
    "closedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Setting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Setting" (
    id text NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: StockMovement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."StockMovement" (
    id text NOT NULL,
    "inventoryItemId" text NOT NULL,
    "movementType" public."InventoryMovementType" NOT NULL,
    quantity numeric(12,2) NOT NULL,
    "previousQuantity" numeric(12,2) NOT NULL,
    "newQuantity" numeric(12,2) NOT NULL,
    "relatedEntityType" text,
    "relatedEntityId" text,
    reason text,
    "performedByAdminId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Supplier; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Supplier" (
    id text NOT NULL,
    "supplierName" text NOT NULL,
    phone text,
    email text,
    address text,
    "contactPerson" text,
    notes text
);


--
-- Name: Vehicle; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Vehicle" (
    id text NOT NULL,
    "customerId" text NOT NULL,
    "vehicleType" public."VehicleType" NOT NULL,
    "registrationNumber" text NOT NULL,
    brand text NOT NULL,
    model text NOT NULL,
    variant text,
    "yearOfManufacture" integer,
    "fuelType" text,
    transmission text,
    color text,
    vin text,
    "chassisNumber" text,
    "engineNumber" text,
    "engineCC" integer,
    "odometerReading" integer,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Worker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Worker" (
    id text NOT NULL,
    "workerCode" text NOT NULL,
    "fullName" text NOT NULL,
    "phoneNumber" text,
    email text,
    designation text,
    specialization text,
    "employmentType" text,
    "joiningDate" timestamp(3) without time zone,
    "dailyCapacity" integer,
    "shiftStart" text,
    "shiftEnd" text,
    status public."WorkerStatus" DEFAULT 'ACTIVE'::public."WorkerStatus" NOT NULL,
    "emergencyContactName" text,
    "emergencyContactPhone" text,
    address text,
    notes text,
    "monthlySalary" numeric(10,2),
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: WorkerAssignment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."WorkerAssignment" (
    id text NOT NULL,
    "jobCardId" text NOT NULL,
    "workerId" text NOT NULL,
    "assignmentRole" text,
    "assignedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "unassignedAt" timestamp(3) without time zone,
    notes text
);


--
-- Name: WorkerLeave; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."WorkerLeave" (
    id text NOT NULL,
    "workerId" text NOT NULL,
    "leaveType" text NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "partialDay" boolean DEFAULT false NOT NULL,
    "partialStartTime" text,
    "partialEndTime" text,
    status public."LeaveStatus" DEFAULT 'PENDING'::public."LeaveStatus" NOT NULL,
    reason text,
    "approvedByAdminId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: ActivityLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ActivityLog" (id, "entityType", "entityId", action, "previousValueJson", "newValueJson", "actorType", "actorId", "requestId", "ipAddress", "userAgent", "createdAt") FROM stdin;
cmq8ffr8100016w2p3veguurp	AdminUser	cmq8eh4ei0006tk9wa9s35hy4	auth.login	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	::1	curl/8.7.1	2026-06-10 18:53:29.617
cmq8fq2sb0001i6kf648kza0x	AdminUser	cmq8eh4ei0006tk9wa9s35hy4	auth.login	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	::1	curl/8.7.1	2026-06-10 19:01:31.163
cmq8fs0pu0003i6kfbixjmumz	AdminUser	cmq8eh4ei0006tk9wa9s35hy4	auth.login	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	::1	curl/8.7.1	2026-06-10 19:03:01.794
cmq8fs9xb0001nasv21enggaf	AdminUser	cmq8eh4ei0006tk9wa9s35hy4	auth.login	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	152.58.139.113	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36	2026-06-10 19:03:13.728
cmq8fsna0000ci6kfw2mhmuj3	Appointment	cmq8fskk6000ai6kfwhophszx	appointment.created	\N	{"id": "cmq8fskk6000ai6kfwhophszx", "bayId": null, "status": "CONFIRMED", "slotEnd": "2026-06-20T10:00:00.000Z", "createdAt": "2026-06-10T19:03:27.510Z", "slotStart": "2026-06-20T09:00:00.000Z", "updatedAt": "2026-06-10T19:03:27.510Z", "vehicleId": "cmq8eirvx0030tk9wvczo33g6", "customerId": "cmq8eim6z002gtk9wm1yn00a2", "referenceId": "APT-EKIXJNASUIDG", "bookingSource": "WALK_IN", "appointmentDate": "2026-06-20T00:00:00.000Z", "assignedWorkerId": "cmq8ej36f003atk9wucd5ypah", "confirmationMode": null, "rescheduleReason": null, "serviceRequestId": null, "cancellationReason": null, "confirmedByAdminId": "cmq8eh4ei0006tk9wa9s35hy4"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-10 19:03:27.953
cmq8xyv3l0001ei5iawazxjl9	AdminUser	cmq8eh4ei0006tk9wa9s35hy4	auth.login	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	49.47.154.16	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 03:32:14.194
cmq8y4e7d0001tcfql7kfoq5n	AdminUser	cmq8eh4ei0006tk9wa9s35hy4	auth.login	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	49.206.9.144	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-11 03:36:32.233
cmq8yi3ki00015638sa08exkf	AdminUser	cmq8eh4ei0006tk9wa9s35hy4	auth.login	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	49.47.154.16	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 03:47:11.635
cmq8yz8ud0004ei5ih2016gqd	Customer	cmq8yz8tu0002ei5io346nbz6	customer.created	\N	{"id": "cmq8yz8tu0002ei5io346nbz6", "city": null, "email": "gearup.sgnk.ai@gmail.com", "notes": null, "state": null, "source": "JOB_CARD_FORM", "fullName": "shanti ranjan kar", "createdAt": "2026-06-11T04:00:31.583Z", "updatedAt": "2026-06-11T04:00:31.583Z", "archivedAt": null, "postalCode": null, "phoneNumber": "9832758529", "addressLine1": null, "addressLine2": null, "alternatePhone": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:00:31.621
cmq8z0hqp0008ei5ih3qqe6yh	Vehicle	cmq8z0hq40006ei5ifaqsfpcr	vehicle.created	\N	{"id": "cmq8z0hq40006ei5ifaqsfpcr", "vin": null, "brand": "tvs ", "color": null, "model": "xl100", "notes": null, "variant": null, "engineCC": null, "fuelType": null, "createdAt": "2026-06-11T04:01:29.778Z", "updatedAt": "2026-06-11T04:01:29.778Z", "customerId": "cmq8yz8tu0002ei5io346nbz6", "vehicleType": "BIKE", "engineNumber": null, "transmission": null, "chassisNumber": null, "odometerReading": null, "yearOfManufacture": null, "registrationNumber": "WB-68-W-4828"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:01:29.81
cmq8z0ylu000dei5iincod2wn	JobCard	cmq8z0yj4000aei5ir1tgdsfe	job-card.created	\N	{"id": "cmq8z0yj4000aei5ir1tgdsfe", "status": "CREATED", "priority": "", "createdAt": "2026-06-11T04:01:51.561Z", "updatedAt": "2026-06-11T04:01:51.561Z", "vehicleId": "cmq8z0hq40006ei5ifaqsfpcr", "customerId": "cmq8yz8tu0002ei5io346nbz6", "finalTotal": "0", "intakeDate": "2026-06-11T04:01:51.560Z", "issueSummary": "general servicing", "appointmentId": null, "estimateNotes": null, "fuelIndicator": "1/2", "internalNotes": null, "jobCardNumber": "JC-QC88LOT4", "approvalStatus": "PENDING", "diagnosisNotes": null, "estimatedTotal": "0", "finalLaborCost": "0", "finalOtherCost": "0", "finalPartsCost": "0", "actualDeliveryAt": null, "odometerAtIntake": 5668, "serviceRequestId": null, "customerComplaints": "", "estimatedLaborCost": "0", "estimatedOtherCost": "0", "estimatedPartsCost": "0", "estimatedDeliveryAt": null, "customerVisibleNotes": null, "assignedServiceManagerId": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:01:51.667
cmq8zbs5w000fei5isudmvw69	JobCard	cmq8z0yj4000aei5ir1tgdsfe	job-card.updated	\N	{"issueSummary": "general servicing mobil change castrol"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:10:16.532
cmq8zftcb00015ikcu12dw1ka	AdminUser	cmq8eh4ei0006tk9wa9s35hy4	auth.login	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	152.58.162.29	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36	2026-06-11 04:13:24.683
cmq8zfu3q00035ikchkrxl2eq	AdminUser	cmq8eh4ei0006tk9wa9s35hy4	auth.login	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	152.58.162.29	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36	2026-06-11 04:13:25.671
cmq8zgfkj0002c0up0r8410b8	Customer	cmq8zgfk10000c0uptfnpc77f	customer.created	\N	{"id": "cmq8zgfk10000c0uptfnpc77f", "city": null, "email": "gearup.sgnk.ai@gmail.com", "notes": null, "state": null, "source": "JOB_CARD_FORM", "fullName": "Tapas Tantubai", "createdAt": "2026-06-11T04:13:53.473Z", "updatedAt": "2026-06-11T04:13:53.473Z", "archivedAt": null, "postalCode": null, "phoneNumber": "9851841943", "addressLine1": null, "addressLine2": null, "alternatePhone": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:13:53.492
cmq8zgx7a0006c0up9470ligb	Vehicle	cmq8zgx6t0004c0up8blgf3a3	vehicle.created	\N	{"id": "cmq8zgx6t0004c0up8blgf3a3", "vin": null, "brand": "Avengers ", "color": null, "model": "B4", "notes": null, "variant": null, "engineCC": null, "fuelType": null, "createdAt": "2026-06-11T04:14:16.321Z", "updatedAt": "2026-06-11T04:14:16.321Z", "customerId": "cmq8zgfk10000c0uptfnpc77f", "vehicleType": "BIKE", "engineNumber": null, "transmission": null, "chassisNumber": null, "odometerReading": null, "yearOfManufacture": null, "registrationNumber": "WB-68-W-4341"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:14:16.342
cmq8zhnfy000bc0uppt93m55k	JobCard	cmq8zhndk0008c0upmdloj9do	job-card.created	\N	{"id": "cmq8zhndk0008c0upmdloj9do", "status": "CREATED", "priority": "", "createdAt": "2026-06-11T04:14:50.258Z", "updatedAt": "2026-06-11T04:14:50.258Z", "vehicleId": "cmq8zgx6t0004c0up8blgf3a3", "customerId": "cmq8zgfk10000c0uptfnpc77f", "finalTotal": "0", "intakeDate": "2026-06-11T04:14:50.257Z", "issueSummary": "General Servicing \\nFront brake check \\nFoam wash", "appointmentId": null, "estimateNotes": null, "fuelIndicator": "1/4", "internalNotes": null, "jobCardNumber": "JC-R225V1C3", "approvalStatus": "PENDING", "diagnosisNotes": null, "estimatedTotal": "0", "finalLaborCost": "0", "finalOtherCost": "0", "finalPartsCost": "0", "actualDeliveryAt": null, "odometerAtIntake": 9506, "serviceRequestId": null, "customerComplaints": "", "estimatedLaborCost": "0", "estimatedOtherCost": "0", "estimatedPartsCost": "0", "estimatedDeliveryAt": null, "customerVisibleNotes": null, "assignedServiceManagerId": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:14:50.351
cmq98q5j7000fuif52aa2b5d8	InvoiceLineItem	cmq98pqyv0009uif55c3mofkf	invoice.line.removed	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:33:23.588
cmq98t0yb000ruif5rtefndgw	InvoiceLineItem	cmq98t0v4000nuif5trw5v76r	invoice.line.added	\N	{"taxRate": 0, "lineType": "CUSTOM_CHARGE", "quantity": 1, "unitPrice": 0, "description": "washing charge", "discountPercent": 0}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:35:37.619
cmq8zpxp300024pnf85s1sjzf	Customer	cmq8zpxoa00004pnfqeua0fxf	customer.created	\N	{"id": "cmq8zpxoa00004pnfqeua0fxf", "city": null, "email": "gearup.sgnk.ai@gmail.com", "notes": null, "state": null, "source": "JOB_CARD_FORM", "fullName": "Sudip Karmakar ", "createdAt": "2026-06-11T04:21:16.858Z", "updatedAt": "2026-06-11T04:21:16.858Z", "archivedAt": null, "postalCode": null, "phoneNumber": "8016197754", "addressLine1": null, "addressLine2": null, "alternatePhone": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:21:16.887
cmq8zqd4g00064pnfwtcok8tz	Vehicle	cmq8zqd3m00044pnf93zcloss	vehicle.created	\N	{"id": "cmq8zqd3m00044pnf93zcloss", "vin": null, "brand": "Honda ", "color": null, "model": "Hornet", "notes": null, "variant": null, "engineCC": null, "fuelType": null, "createdAt": "2026-06-11T04:21:36.851Z", "updatedAt": "2026-06-11T04:21:36.851Z", "customerId": "cmq8zpxoa00004pnfqeua0fxf", "vehicleType": "BIKE", "engineNumber": null, "transmission": null, "chassisNumber": null, "odometerReading": null, "yearOfManufacture": null, "registrationNumber": "WB-67-H-6582"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:21:36.88
cmq8zwsm5000hei5igmmynh1d	AdminUser	cmq8eh4ei0006tk9wa9s35hy4	auth.login	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	49.47.154.16	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 04:26:36.894
cmq906y160002v0ip9xqzeu5l	Customer	cmq906y050000v0ipb3zif22u	customer.created	\N	{"id": "cmq906y050000v0ipb3zif22u", "city": null, "email": "gearup.sgnk.ai@gmail.com", "notes": null, "state": null, "source": "JOB_CARD_FORM", "fullName": "Subrata Mandal", "createdAt": "2026-06-11T04:34:30.429Z", "updatedAt": "2026-06-11T04:34:30.429Z", "archivedAt": null, "postalCode": null, "phoneNumber": "9800574142", "addressLine1": null, "addressLine2": null, "alternatePhone": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:34:30.475
cmq907hjv0006v0ipk7vkdq04	Vehicle	cmq907hjc0004v0ipiiop2nqj	vehicle.created	\N	{"id": "cmq907hjc0004v0ipiiop2nqj", "vin": null, "brand": "Hero ", "color": null, "model": "Hf deluxe ", "notes": null, "variant": null, "engineCC": null, "fuelType": null, "createdAt": "2026-06-11T04:34:55.742Z", "updatedAt": "2026-06-11T04:34:55.742Z", "customerId": "cmq906y050000v0ipb3zif22u", "vehicleType": "BIKE", "engineNumber": null, "transmission": null, "chassisNumber": null, "odometerReading": null, "yearOfManufacture": null, "registrationNumber": "WB-68-N-0885"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:34:55.772
cmq90968t000bv0ipn46n5bco	JobCard	cmq9096670008v0ipef6ae0m3	job-card.created	\N	{"id": "cmq9096670008v0ipef6ae0m3", "status": "CREATED", "priority": "", "createdAt": "2026-06-11T04:36:14.324Z", "updatedAt": "2026-06-11T04:36:14.324Z", "vehicleId": "cmq907hjc0004v0ipiiop2nqj", "customerId": "cmq906y050000v0ipb3zif22u", "finalTotal": "0", "intakeDate": "2026-06-11T04:36:14.324Z", "issueSummary": "Mileage issue\\nMobil check\\nFoam wash ", "appointmentId": null, "estimateNotes": null, "fuelIndicator": "1/4", "internalNotes": null, "jobCardNumber": "JC-JO9QW52H", "approvalStatus": "PENDING", "diagnosisNotes": null, "estimatedTotal": "0", "finalLaborCost": "0", "finalOtherCost": "0", "finalPartsCost": "0", "actualDeliveryAt": null, "odometerAtIntake": 5299, "serviceRequestId": null, "customerComplaints": "", "estimatedLaborCost": "0", "estimatedOtherCost": "0", "estimatedPartsCost": "0", "estimatedDeliveryAt": null, "customerVisibleNotes": null, "assignedServiceManagerId": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:36:14.429
cmq90e6fw000nv0ipzxg5b3cm	JobCard	cmq90e6ci000kv0ipbrl8rywb	job-card.created	\N	{"id": "cmq90e6ci000kv0ipbrl8rywb", "status": "CREATED", "priority": "", "createdAt": "2026-06-11T04:40:07.811Z", "updatedAt": "2026-06-11T04:40:07.811Z", "vehicleId": "cmq90b5ad000gv0ip606qeqm6", "customerId": "cmq90aqgy000cv0ipx2o9ehnl", "finalTotal": "0", "intakeDate": "2026-06-11T04:40:07.810Z", "issueSummary": "General Servicing, Rear break loose, Foam Wash, Engine Oil check, Gear Check", "appointmentId": null, "estimateNotes": null, "fuelIndicator": "E", "internalNotes": null, "jobCardNumber": "JC-LGM922DV", "approvalStatus": "PENDING", "diagnosisNotes": null, "estimatedTotal": "0", "finalLaborCost": "0", "finalOtherCost": "0", "finalPartsCost": "0", "actualDeliveryAt": null, "odometerAtIntake": 14605, "serviceRequestId": null, "customerComplaints": "Scratch ", "estimatedLaborCost": "0", "estimatedOtherCost": "0", "estimatedPartsCost": "0", "estimatedDeliveryAt": null, "customerVisibleNotes": null, "assignedServiceManagerId": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:40:07.965
cmq90qcc60002w352iul7wo0t	Customer	cmq90qcbi0000w352n3yauaux	customer.created	\N	{"id": "cmq90qcbi0000w352n3yauaux", "city": null, "email": "gearup.sgnk.ai@gmail.com", "notes": null, "state": null, "source": "JOB_CARD_FORM", "fullName": "Binit Das", "createdAt": "2026-06-11T04:49:35.455Z", "updatedAt": "2026-06-11T04:49:35.455Z", "archivedAt": null, "postalCode": null, "phoneNumber": "9679828343", "addressLine1": null, "addressLine2": null, "alternatePhone": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:49:35.479
cmq90qum10006w352b2grdeqv	Vehicle	cmq90qukt0004w352hl9rne4u	vehicle.created	\N	{"id": "cmq90qukt0004w352hl9rne4u", "vin": null, "brand": "Royal", "color": null, "model": "Enfield ", "notes": null, "variant": null, "engineCC": null, "fuelType": null, "createdAt": "2026-06-11T04:49:59.097Z", "updatedAt": "2026-06-11T04:49:59.097Z", "customerId": "cmq90qcbi0000w352n3yauaux", "vehicleType": "BIKE", "engineNumber": null, "transmission": null, "chassisNumber": null, "odometerReading": null, "yearOfManufacture": null, "registrationNumber": "WB-68-AF-2813"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:49:59.161
cmq90rmnr000bw3526ftam0bq	JobCard	cmq90rmkl0008w352tck2ie43	job-card.created	\N	{"id": "cmq90rmkl0008w352tck2ie43", "status": "CREATED", "priority": "", "createdAt": "2026-06-11T04:50:35.379Z", "updatedAt": "2026-06-11T04:50:35.379Z", "vehicleId": "cmq90qukt0004w352hl9rne4u", "customerId": "cmq90qcbi0000w352n3yauaux", "finalTotal": "0", "intakeDate": "2026-06-11T04:50:35.378Z", "issueSummary": "General Servicing \\nSelf check\\nBearing check\\nMobil check", "appointmentId": null, "estimateNotes": null, "fuelIndicator": "1/2", "internalNotes": null, "jobCardNumber": "JC-F2A4VYXN", "approvalStatus": "PENDING", "diagnosisNotes": null, "estimatedTotal": "0", "finalLaborCost": "0", "finalOtherCost": "0", "finalPartsCost": "0", "actualDeliveryAt": null, "odometerAtIntake": 9686, "serviceRequestId": null, "customerComplaints": "", "estimatedLaborCost": "0", "estimatedOtherCost": "0", "estimatedPartsCost": "0", "estimatedDeliveryAt": null, "customerVisibleNotes": null, "assignedServiceManagerId": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:50:35.511
cmq911q1y000dw352669g6ibs	JobCard	cmq8z0yj4000aei5ir1tgdsfe	job-card.updated	\N	{"status": "ESTIMATE_PREPARED"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:58:26.47
cmq911rn4000fw3521jekjsor	JobCard	cmq8z0yj4000aei5ir1tgdsfe	job-card.updated	\N	{"status": "WORK_IN_PROGRESS"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:58:28.529
cmq8zs5t80004ogmdu73yrbl6	JobCard	cmq8zs5qt0001ogmd2g7onc6s	job-card.created	\N	{"id": "cmq8zs5qt0001ogmd2g7onc6s", "status": "CREATED", "priority": "", "createdAt": "2026-06-11T04:23:00.625Z", "updatedAt": "2026-06-11T04:23:00.625Z", "vehicleId": "cmq8zqd3m00044pnf93zcloss", "customerId": "cmq8zpxoa00004pnfqeua0fxf", "finalTotal": "0", "intakeDate": "2026-06-11T04:23:00.624Z", "issueSummary": "Foam Wash \\nChain clean \\n", "appointmentId": null, "estimateNotes": null, "fuelIndicator": "1/4", "internalNotes": null, "jobCardNumber": "JC-4AQPSIXJ", "approvalStatus": "PENDING", "diagnosisNotes": null, "estimatedTotal": "0", "finalLaborCost": "0", "finalOtherCost": "0", "finalPartsCost": "0", "actualDeliveryAt": null, "odometerAtIntake": 9865, "serviceRequestId": null, "customerComplaints": "", "estimatedLaborCost": "0", "estimatedOtherCost": "0", "estimatedPartsCost": "0", "estimatedDeliveryAt": null, "customerVisibleNotes": null, "assignedServiceManagerId": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:23:00.716
cmq90aqhg000ev0ip9po0s67n	Customer	cmq90aqgy000cv0ipx2o9ehnl	customer.created	\N	{"id": "cmq90aqgy000cv0ipx2o9ehnl", "city": null, "email": null, "notes": null, "state": null, "source": "JOB_CARD_FORM", "fullName": "Biplab Pati", "createdAt": "2026-06-11T04:37:27.298Z", "updatedAt": "2026-06-11T04:37:27.298Z", "archivedAt": null, "postalCode": null, "phoneNumber": "9647918638", "addressLine1": null, "addressLine2": null, "alternatePhone": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:37:27.316
cmq90b5av000iv0ipe3d7606s	Vehicle	cmq90b5ad000gv0ip606qeqm6	vehicle.created	\N	{"id": "cmq90b5ad000gv0ip606qeqm6", "vin": null, "brand": "Honda", "color": null, "model": "SP125", "notes": null, "variant": null, "engineCC": null, "fuelType": null, "createdAt": "2026-06-11T04:37:46.498Z", "updatedAt": "2026-06-11T04:37:46.498Z", "customerId": "cmq90aqgy000cv0ipx2o9ehnl", "vehicleType": "BIKE", "engineNumber": null, "transmission": null, "chassisNumber": null, "odometerReading": null, "yearOfManufacture": null, "registrationNumber": "WB-68-AM-1263"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 04:37:46.519
cmq9164f7000iw3523gtzav5o	Customer	cmq9164ef000gw352im1qlnev	customer.created	\N	{"id": "cmq9164ef000gw352im1qlnev", "city": null, "email": "gearup.sgnk.ai@gmail.com", "notes": null, "state": null, "source": "JOB_CARD_FORM", "fullName": "Sukhen ", "createdAt": "2026-06-11T05:01:51.682Z", "updatedAt": "2026-06-11T05:01:51.682Z", "archivedAt": null, "postalCode": null, "phoneNumber": "8695291893", "addressLine1": null, "addressLine2": null, "alternatePhone": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 05:01:51.715
cmq916mfu000mw3526z8ugixm	Vehicle	cmq916mf0000kw352sukhqh2a	vehicle.created	\N	{"id": "cmq916mf0000kw352sukhqh2a", "vin": null, "brand": "Royal Enfield ", "color": null, "model": "Classic 350", "notes": null, "variant": null, "engineCC": null, "fuelType": null, "createdAt": "2026-06-11T05:02:15.008Z", "updatedAt": "2026-06-11T05:02:15.008Z", "customerId": "cmq9164ef000gw352im1qlnev", "vehicleType": "BIKE", "engineNumber": null, "transmission": null, "chassisNumber": null, "odometerReading": null, "yearOfManufacture": null, "registrationNumber": "WB-68-AP-6411"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 05:02:15.066
cmq916uzh000rw352l0eq07rg	JobCard	cmq916uvk000ow352jjiacaui	job-card.created	\N	{"id": "cmq916uvk000ow352jjiacaui", "status": "CREATED", "priority": "", "createdAt": "2026-06-11T05:02:25.984Z", "updatedAt": "2026-06-11T05:02:25.984Z", "vehicleId": "cmq916mf0000kw352sukhqh2a", "customerId": "cmq9164ef000gw352im1qlnev", "finalTotal": "0", "intakeDate": "2026-06-11T05:02:25.983Z", "issueSummary": "Foam wash ", "appointmentId": null, "estimateNotes": null, "fuelIndicator": "1/2", "internalNotes": null, "jobCardNumber": "JC-WVPBWGSW", "approvalStatus": "PENDING", "diagnosisNotes": null, "estimatedTotal": "0", "finalLaborCost": "0", "finalOtherCost": "0", "finalPartsCost": "0", "actualDeliveryAt": null, "odometerAtIntake": 68062, "serviceRequestId": null, "customerComplaints": "", "estimatedLaborCost": "0", "estimatedOtherCost": "0", "estimatedPartsCost": "0", "estimatedDeliveryAt": null, "customerVisibleNotes": null, "assignedServiceManagerId": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 05:02:26.141
cmq92syuv0002q3jponqae6yd	Customer	cmq92syu40000q3jpsrf3z87h	customer.created	\N	{"id": "cmq92syu40000q3jpsrf3z87h", "city": null, "email": null, "notes": null, "state": null, "source": "JOB_CARD_FORM", "fullName": "Sumanta Mukherjee ", "createdAt": "2026-06-11T05:47:37.177Z", "updatedAt": "2026-06-11T05:47:37.177Z", "archivedAt": null, "postalCode": null, "phoneNumber": "9064458228", "addressLine1": null, "addressLine2": null, "alternatePhone": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 05:47:37.208
cmq92ucj20006q3jp3gdxuvl1	Vehicle	cmq92ucij0004q3jp9rbw3nli	vehicle.created	\N	{"id": "cmq92ucij0004q3jp9rbw3nli", "vin": null, "brand": "Honda", "color": null, "model": "Dream Neo 110", "notes": null, "variant": null, "engineCC": null, "fuelType": null, "createdAt": "2026-06-11T05:48:41.557Z", "updatedAt": "2026-06-11T05:48:41.557Z", "customerId": "cmq92syu40000q3jpsrf3z87h", "vehicleType": "BIKE", "engineNumber": null, "transmission": null, "chassisNumber": null, "odometerReading": null, "yearOfManufacture": null, "registrationNumber": "WB-68-R-2377"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 05:48:41.583
cmq92yrox000bq3jpx8vf64oh	JobCard	cmq92yrma0008q3jpgvtowqan	job-card.created	\N	{"id": "cmq92yrma0008q3jpgvtowqan", "status": "CREATED", "priority": "", "createdAt": "2026-06-11T05:52:07.757Z", "updatedAt": "2026-06-11T05:52:07.757Z", "vehicleId": "cmq92ucij0004q3jp9rbw3nli", "customerId": "cmq92syu40000q3jpsrf3z87h", "finalTotal": "0", "intakeDate": "2026-06-11T05:52:07.756Z", "issueSummary": "Mobil Change Castrol, Clutch Adjust, Chain Adjust, Air Filter Check, General Servicing ", "appointmentId": null, "estimateNotes": null, "fuelIndicator": "E", "internalNotes": null, "jobCardNumber": "JC-CGWF0WXP", "approvalStatus": "PENDING", "diagnosisNotes": null, "estimatedTotal": "0", "finalLaborCost": "0", "finalOtherCost": "0", "finalPartsCost": "0", "actualDeliveryAt": null, "odometerAtIntake": 43371, "serviceRequestId": null, "customerComplaints": "", "estimatedLaborCost": "0", "estimatedOtherCost": "0", "estimatedPartsCost": "0", "estimatedDeliveryAt": null, "customerVisibleNotes": null, "assignedServiceManagerId": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 05:52:07.857
cmq9321yo000eq3jpfi6wgdn7	Customer	cmq9321y4000cq3jpjjbuad34	customer.created	\N	{"id": "cmq9321y4000cq3jpjjbuad34", "city": null, "email": null, "notes": null, "state": null, "source": "JOB_CARD_FORM", "fullName": "Debabrata Patra", "createdAt": "2026-06-11T05:54:41.112Z", "updatedAt": "2026-06-11T05:54:41.112Z", "archivedAt": null, "postalCode": null, "phoneNumber": "7407944841", "addressLine1": null, "addressLine2": null, "alternatePhone": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 05:54:41.136
cmq932ico000iq3jpzswe0op1	Vehicle	cmq932ic7000gq3jprhxini79	vehicle.created	\N	{"id": "cmq932ic7000gq3jprhxini79", "vin": null, "brand": "Hero ", "color": null, "model": "Glamour ", "notes": null, "variant": null, "engineCC": null, "fuelType": null, "createdAt": "2026-06-11T05:55:02.350Z", "updatedAt": "2026-06-11T05:55:02.350Z", "customerId": "cmq9321y4000cq3jpjjbuad34", "vehicleType": "BIKE", "engineNumber": null, "transmission": null, "chassisNumber": null, "odometerReading": null, "yearOfManufacture": null, "registrationNumber": "WB-68-AG-6605"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 05:55:02.376
cmq98t1ws000tuif52224pn2y	Invoice	cmq916ux6000pw3520720u1ao	invoice.finalized	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:35:38.861
cmq98t8m1000vuif5cgrf7fdy	Invoice	cmq916ux6000pw3520720u1ao	invoice.reverted-to-draft	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:35:47.545
cmq9345w8000nq3jpx75qpt3g	JobCard	cmq9345tu000kq3jpytm93djn	job-card.created	\N	{"id": "cmq9345tu000kq3jpytm93djn", "status": "CREATED", "priority": "", "createdAt": "2026-06-11T05:56:19.451Z", "updatedAt": "2026-06-11T05:56:19.451Z", "vehicleId": "cmq932ic7000gq3jprhxini79", "customerId": "cmq9321y4000cq3jpjjbuad34", "finalTotal": "0", "intakeDate": "2026-06-11T05:56:19.450Z", "issueSummary": "Foam Wash ", "appointmentId": null, "estimateNotes": null, "fuelIndicator": "3/4", "internalNotes": null, "jobCardNumber": "JC-D5SCQAQY", "approvalStatus": "PENDING", "diagnosisNotes": null, "estimatedTotal": "0", "finalLaborCost": "0", "finalOtherCost": "0", "finalPartsCost": "0", "actualDeliveryAt": null, "odometerAtIntake": 57742, "serviceRequestId": null, "customerComplaints": "", "estimatedLaborCost": "0", "estimatedOtherCost": "0", "estimatedPartsCost": "0", "estimatedDeliveryAt": null, "customerVisibleNotes": null, "assignedServiceManagerId": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 05:56:19.544
cmq93no790005pdphg4zgoxsj	InvoiceLineItem	cmq93no4l0001pdph8b908yue	invoice.line.added	\N	{"taxRate": 0, "lineType": "SERVICE_CHARGE", "quantity": 1, "unitPrice": 25, "description": "CHAIN CLEAN", "discountPercent": 0}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:11:29.734
cmq93nvb4000bpdphfl2ey38e	InvoiceLineItem	cmq93nv8s0007pdphv6zc78p8	invoice.line.added	\N	{"taxRate": 0, "lineType": "SERVICE_CHARGE", "quantity": 1, "unitPrice": 49, "description": "FOAM WASH", "discountPercent": 0}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:11:38.944
cmq93nx0c000dpdphrv7lmj14	Invoice	cmq8zs5rz0002ogmd9zwxup9e	invoice.finalized	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:11:41.148
cmq93o19k0004984m4dthxfnj	Payment	cmq93o1870002984m7o19byqd	payment.recorded	\N	{"amount": 74, "paymentDate": "2026-06-11T00:00:00+05:30", "paymentMode": "UPI"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:11:46.665
cmq93vtf9000gpdphk0nwannb	Customer	cmq93vtem000epdphfnndmaf5	customer.created	\N	{"id": "cmq93vtem000epdphfnndmaf5", "city": null, "email": "gearup.sgnk.ai@gmail.com", "notes": null, "state": null, "source": "JOB_CARD_FORM", "fullName": "ABIR DASMODAK ", "createdAt": "2026-06-11T06:17:49.722Z", "updatedAt": "2026-06-11T06:17:49.722Z", "archivedAt": null, "postalCode": null, "phoneNumber": "9832201386", "addressLine1": null, "addressLine2": null, "alternatePhone": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:17:49.749
cmq93wc14000kpdphvvls7pkn	Vehicle	cmq93wc0i000ipdphqz3sbeul	vehicle.created	\N	{"id": "cmq93wc0i000ipdphqz3sbeul", "vin": null, "brand": "HORNET ", "color": null, "model": "160", "notes": null, "variant": null, "engineCC": null, "fuelType": null, "createdAt": "2026-06-11T06:18:13.823Z", "updatedAt": "2026-06-11T06:18:13.823Z", "customerId": "cmq93vtem000epdphfnndmaf5", "vehicleType": "BIKE", "engineNumber": null, "transmission": null, "chassisNumber": null, "odometerReading": null, "yearOfManufacture": null, "registrationNumber": "WB-68-W-9225"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:18:13.865
cmq93x2ez000ppdphssnc88m0	JobCard	cmq93x2bu000mpdphexus3983	job-card.created	\N	{"id": "cmq93x2bu000mpdphexus3983", "status": "CREATED", "priority": "", "createdAt": "2026-06-11T06:18:47.933Z", "updatedAt": "2026-06-11T06:18:47.933Z", "vehicleId": "cmq93wc0i000ipdphqz3sbeul", "customerId": "cmq93vtem000epdphfnndmaf5", "finalTotal": "0", "intakeDate": "2026-06-11T06:18:47.933Z", "issueSummary": "FOAM WASH ", "appointmentId": null, "estimateNotes": null, "fuelIndicator": "1/2", "internalNotes": null, "jobCardNumber": "JC-G6ORWAI0", "approvalStatus": "PENDING", "diagnosisNotes": null, "estimatedTotal": "0", "finalLaborCost": "0", "finalOtherCost": "0", "finalPartsCost": "0", "actualDeliveryAt": null, "odometerAtIntake": 5662, "serviceRequestId": null, "customerComplaints": "", "estimatedLaborCost": "0", "estimatedOtherCost": "0", "estimatedPartsCost": "0", "estimatedDeliveryAt": null, "customerVisibleNotes": null, "assignedServiceManagerId": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:18:48.059
cmq93zs0g000spdphob7kw95i	Customer	cmq93zrzr000qpdph0uog4py3	customer.created	\N	{"id": "cmq93zrzr000qpdph0uog4py3", "city": null, "email": "gearup.sgnk.ai@gmail.com", "notes": null, "state": null, "source": "JOB_CARD_FORM", "fullName": "GOURAV BHATTACHARYAA", "createdAt": "2026-06-11T06:20:54.515Z", "updatedAt": "2026-06-11T06:20:54.515Z", "archivedAt": null, "postalCode": null, "phoneNumber": "7550883795", "addressLine1": null, "addressLine2": null, "alternatePhone": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:20:54.544
cmq9407qy000wpdphuenn3u6j	Vehicle	cmq9407qc000updphadqqd9b2	vehicle.created	\N	{"id": "cmq9407qc000updphadqqd9b2", "vin": null, "brand": "R ", "color": null, "model": "15", "notes": null, "variant": null, "engineCC": null, "fuelType": null, "createdAt": "2026-06-11T06:21:14.904Z", "updatedAt": "2026-06-11T06:21:14.904Z", "customerId": "cmq93zrzr000qpdph0uog4py3", "vehicleType": "BIKE", "engineNumber": null, "transmission": null, "chassisNumber": null, "odometerReading": null, "yearOfManufacture": null, "registrationNumber": "WB-68-AN-1061"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:21:14.939
cmq940qxx0011pdph3tcza65q	JobCard	cmq940qut000ypdphcqnz22b2	job-card.created	\N	{"id": "cmq940qut000ypdphcqnz22b2", "status": "CREATED", "priority": "", "createdAt": "2026-06-11T06:21:39.663Z", "updatedAt": "2026-06-11T06:21:39.663Z", "vehicleId": "cmq9407qc000updphadqqd9b2", "customerId": "cmq93zrzr000qpdph0uog4py3", "finalTotal": "0", "intakeDate": "2026-06-11T06:21:39.660Z", "issueSummary": "NORMAL WASH", "appointmentId": null, "estimateNotes": null, "fuelIndicator": "1/2", "internalNotes": null, "jobCardNumber": "JC-9D63LOKF", "approvalStatus": "PENDING", "diagnosisNotes": null, "estimatedTotal": "0", "finalLaborCost": "0", "finalOtherCost": "0", "finalPartsCost": "0", "actualDeliveryAt": null, "odometerAtIntake": 5656, "serviceRequestId": null, "customerComplaints": "", "estimatedLaborCost": "0", "estimatedOtherCost": "0", "estimatedPartsCost": "0", "estimatedDeliveryAt": null, "customerVisibleNotes": null, "assignedServiceManagerId": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:21:39.813
cmq94p39w0002qplb7esmgmex	Customer	cmq94p3920000qplb19fz53pl	customer.created	\N	{"id": "cmq94p3920000qplb19fz53pl", "city": null, "email": null, "notes": null, "state": null, "source": "JOB_CARD_FORM", "fullName": "SANAT BOSE", "createdAt": "2026-06-11T06:40:35.506Z", "updatedAt": "2026-06-11T06:40:35.506Z", "archivedAt": null, "postalCode": null, "phoneNumber": "8670518015", "addressLine1": null, "addressLine2": null, "alternatePhone": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:40:35.54
cmq94px8d0006qplbi9r9qt0b	Vehicle	cmq94px7i0004qplberzhfail	vehicle.created	\N	{"id": "cmq94px7i0004qplberzhfail", "vin": null, "brand": "HONDA", "color": null, "model": "ACTIVA ", "notes": null, "variant": null, "engineCC": null, "fuelType": null, "createdAt": "2026-06-11T06:41:14.319Z", "updatedAt": "2026-06-11T06:41:14.319Z", "customerId": "cmq94p3920000qplb19fz53pl", "vehicleType": "BIKE", "engineNumber": null, "transmission": null, "chassisNumber": null, "odometerReading": null, "yearOfManufacture": null, "registrationNumber": "WB-68-Z-7041"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:41:14.366
cmq98qb80000luif5zuiqigrk	InvoiceLineItem	cmq98qb4z000huif54xi3zvfr	invoice.line.added	\N	{"taxRate": 0, "lineType": "AMC", "quantity": 1, "amcPlanId": "cmq95rpld000023mdg7rzokgj", "unitPrice": 1650, "description": "AMC — GOLD (350cc+)", "discountPercent": 10}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:33:30.96
cmq94q795000bqplbdu1ay3ar	JobCard	cmq94q7600008qplbsmhf4nq9	job-card.created	\N	{"id": "cmq94q7600008qplbsmhf4nq9", "status": "CREATED", "priority": "", "createdAt": "2026-06-11T06:41:27.236Z", "updatedAt": "2026-06-11T06:41:27.236Z", "vehicleId": "cmq94px7i0004qplberzhfail", "customerId": "cmq94p3920000qplb19fz53pl", "finalTotal": "0", "intakeDate": "2026-06-11T06:41:27.235Z", "issueSummary": "GENERAL SERVICING ", "appointmentId": null, "estimateNotes": null, "fuelIndicator": "1/4", "internalNotes": null, "jobCardNumber": "JC-NHYTALAW", "approvalStatus": "PENDING", "diagnosisNotes": null, "estimatedTotal": "0", "finalLaborCost": "0", "finalOtherCost": "0", "finalPartsCost": "0", "actualDeliveryAt": null, "odometerAtIntake": 8642, "serviceRequestId": null, "customerComplaints": "", "estimatedLaborCost": "0", "estimatedOtherCost": "0", "estimatedPartsCost": "0", "estimatedDeliveryAt": null, "customerVisibleNotes": null, "assignedServiceManagerId": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:41:27.353
cmq94s18v0005cw11tl48m5qm	InvoiceLineItem	cmq94s1740001cw11qoiyw162	invoice.line.added	\N	{"taxRate": 0, "lineType": "CUSTOM_CHARGE", "quantity": 1, "unitPrice": 400, "description": "CASTROL 10W30", "discountPercent": 5}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:42:52.879
cmq94s7ba00058xw0rrafflj2	InvoiceLineItem	cmq94s79d00018xw0dmzleeh1	invoice.line.added	\N	{"taxRate": 0, "lineType": "SERVICE_CHARGE", "quantity": 1, "unitPrice": 370, "description": "General Service", "discountPercent": 0}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:43:00.743
cmq94slra0007cw116uwwvkup	Invoice	cmq94q77b0009qplbs2jqz4au	invoice.finalized	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:43:19.463
cmq94y9eo000ccw11h92hib2q	Payment	cmq94y9dp000acw11je17l480	payment.recorded	\N	{"amount": 750, "paymentDate": "2026-06-11T00:00:00+05:30", "paymentMode": "CASH"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:47:43.392
cmq958ng3000icw117xmauelu	InvoiceLineItem	cmq958ned000ecw11e0yg5qgk	invoice.line.added	\N	{"taxRate": 0, "lineType": "SERVICE_CHARGE", "quantity": 1, "unitPrice": 49, "description": "FOAM WASH", "discountPercent": 0}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:55:48.148
cmq958p4h00078xw08lercfcg	Invoice	cmq9345uu000lq3jpvlx0szcg	invoice.finalized	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:55:50.321
cmq958s6v000c8xw0bxsrpcgt	Payment	cmq958s5t000a8xw062h5rbki	payment.recorded	\N	{"amount": 49, "paymentDate": "2026-06-11T00:00:00+05:30", "paymentMode": "UPI"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:55:54.296
cmq95ac35000f8xw0o1rhcj1l	Customer	cmq95ac2j000d8xw0nzx65tyh	customer.created	\N	{"id": "cmq95ac2j000d8xw0nzx65tyh", "city": null, "email": "gearup.sgnk.ai@gmail.com", "notes": null, "state": null, "source": "JOB_CARD_FORM", "fullName": "PRADIP KUMAR MODAK", "createdAt": "2026-06-11T06:57:06.711Z", "updatedAt": "2026-06-11T06:57:06.711Z", "archivedAt": null, "postalCode": null, "phoneNumber": "9933593493", "addressLine1": null, "addressLine2": null, "alternatePhone": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:57:06.737
cmq95awcz000j8xw0akr51dnt	Vehicle	cmq95awcf000h8xw0bjuy7tzj	vehicle.created	\N	{"id": "cmq95awcf000h8xw0bjuy7tzj", "vin": null, "brand": "CLASSIC", "color": null, "model": "350", "notes": null, "variant": null, "engineCC": null, "fuelType": null, "createdAt": "2026-06-11T06:57:32.979Z", "updatedAt": "2026-06-11T06:57:32.979Z", "customerId": "cmq95ac2j000d8xw0nzx65tyh", "vehicleType": "BIKE", "engineNumber": null, "transmission": null, "chassisNumber": null, "odometerReading": null, "yearOfManufacture": null, "registrationNumber": "W-68-AQ-3433"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:57:33.011
cmq95balq000o8xw05q0f1rzl	JobCard	cmq95baj2000l8xw07dglk68b	job-card.created	\N	{"id": "cmq95baj2000l8xw07dglk68b", "status": "CREATED", "priority": "", "createdAt": "2026-06-11T06:57:51.364Z", "updatedAt": "2026-06-11T06:57:51.364Z", "vehicleId": "cmq95awcf000h8xw0bjuy7tzj", "customerId": "cmq95ac2j000d8xw0nzx65tyh", "finalTotal": "0", "intakeDate": "2026-06-11T06:57:51.363Z", "issueSummary": "FOAM WASH ", "appointmentId": null, "estimateNotes": null, "fuelIndicator": "1/4", "internalNotes": null, "jobCardNumber": "JC-HRQR3L5S", "approvalStatus": "PENDING", "diagnosisNotes": null, "estimatedTotal": "0", "finalLaborCost": "0", "finalOtherCost": "0", "finalPartsCost": "0", "actualDeliveryAt": null, "odometerAtIntake": 5565, "serviceRequestId": null, "customerComplaints": "", "estimatedLaborCost": "0", "estimatedOtherCost": "0", "estimatedPartsCost": "0", "estimatedDeliveryAt": null, "customerVisibleNotes": null, "assignedServiceManagerId": null}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:57:51.47
cmq95ci5u000q8xw0umr85rkk	JobCard	cmq95baj2000l8xw07dglk68b	job-card.updated	\N	{"issueSummary": "FOAM WASH SILICON POLISH"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 06:58:47.923
cmq983rcg00058ev6581ae3u0	InvoiceLineItem	cmq983r9f00018ev6fdrk3tiy	invoice.line.added	\N	{"taxRate": 0, "lineType": "CUSTOM_CHARGE", "quantity": 1, "unitPrice": 350, "description": "Labour charges ", "discountPercent": 0}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:15:58.769
cmq984f8g0005galz3bx6mm4g	InvoiceLineItem	cmq984f5f0001galzt4ge8bgb	invoice.line.added	\N	{"taxRate": 0, "lineType": "CUSTOM_CHARGE", "quantity": 1, "unitPrice": 470, "description": "Castrol 20w40", "discountPercent": 50}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:16:29.728
cmq984nph0007galz4tjkd6yk	InvoiceLineItem	cmq984f5f0001galzt4ge8bgb	invoice.line.removed	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:16:40.709
cmq9859fa000b8ev6g3ucdo1f	InvoiceLineItem	cmq9859cf00078ev6rk8d52rv	invoice.line.added	\N	{"taxRate": 0, "lineType": "SERVICE_CHARGE", "quantity": 1, "unitPrice": 470, "description": "Activ Castrol 20w40", "discountPercent": 50}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:17:08.854
cmq985jsj000d8ev60plcleus	InvoiceLineItem	cmq9859cf00078ev6rk8d52rv	invoice.line.removed	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:17:22.292
cmq9865p3000j8ev6eec47inu	InvoiceLineItem	cmq9865m2000f8ev6loxjroz4	invoice.line.added	\N	{"taxRate": 0, "lineType": "SERVICE_CHARGE", "quantity": 1, "unitPrice": 470, "description": "Activ Castrol 20w40 ", "discountPercent": 5}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:17:50.68
cmq986lzs0009galzynvyzbd0	Invoice	cmq8z0yke000bei5ikzc3h6wc	invoice.finalized	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:18:11.8
cmq98pd8u0005uif52purq2oj	InvoiceLineItem	cmq98pd5p0001uif544eetkrd	invoice.line.added	\N	{"taxRate": 0, "lineType": "AMC", "quantity": 1, "amcPlanId": "cmq95rpld000023mdg7rzokgj", "unitPrice": 1650, "description": "AMC — GOLD (350cc+)", "discountPercent": 10}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:32:46.926
cmq98pjg10007uif5pxcgkmrt	InvoiceLineItem	cmq98pd5p0001uif544eetkrd	invoice.line.removed	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:32:54.962
cmq98pr2b000duif52k3jcpcj	InvoiceLineItem	cmq98pqyv0009uif55c3mofkf	invoice.line.added	\N	{"taxRate": 0, "lineType": "AMC", "quantity": 1, "amcPlanId": "cmq95rpld000023mdg7rzokgj", "unitPrice": 1650, "description": "AMC — GOLD (350cc+)", "discountPercent": 10}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:33:04.836
cmq98taaf000xuif54fqhszmx	InvoiceLineItem	cmq98t0v4000nuif5trw5v76r	invoice.line.removed	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:35:49.72
cmq98tl7l0013uif5nl9x7mex	InvoiceLineItem	cmq98tl4i000zuif55kd3y0dr	invoice.line.added	\N	{"taxRate": 0, "lineType": "SERVICE_CHARGE", "quantity": 1, "unitPrice": 49, "description": "foam wash ", "discountPercent": 0}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:36:03.874
cmq98tmt40001nxsqqs2633rw	Invoice	cmq916ux6000pw3520720u1ao	invoice.finalized	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:36:05.945
cmq98tq3l0006nxsq96xfkyn2	Payment	cmq98tq1k0004nxsqasobvisp	payment.recorded	\N	{"amount": 49, "paymentDate": "2026-06-11T00:00:00+05:30", "paymentMode": "UPI"}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:36:10.209
cmq996xkt0001e1hkzznt69qb	InvoiceLineItem	cmq98qb4z000huif54xi3zvfr	invoice.line.removed	\N	\N	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:46:26.429
cmq9970md0007e1hk5n5tep89	InvoiceLineItem	cmq9970kq0003e1hksek0oc19	invoice.line.added	\N	{"taxRate": 0, "lineType": "AMC", "quantity": 1, "amcPlanId": "cmq95rpld000023mdg7rzokgj", "unitPrice": 1485, "description": "AMC — GOLD (350cc+)", "discountPercent": 0}	ADMIN	cmq8eh4ei0006tk9wa9s35hy4	\N	\N	\N	2026-06-11 08:46:30.373
\.


--
-- Data for Name: AdminUser; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AdminUser" (id, "adminUserId", "fullName", email, phone, "passwordHash", status, "failedLoginAttempts", "lockedUntil", "lastLoginAt", "createdAt", "updatedAt") FROM stdin;
cmq8eh2dh0004tk9wdqt3azhy	priya	Priya Chatterjee	priya@gearup.local	9830067890	$2a$12$C9xwrVElQn8c4CdfM/VUuuczmpLRDPbUSpi6ouS6mcWFZtEuWJltW	ACTIVE	0	\N	\N	2026-06-10 18:26:31.109	2026-06-10 18:26:31.109
cmq8eh3dm0005tk9wa7k0g30s	arnab	Arnab Sen	arnab@gearup.local	9830054321	$2a$12$C9xwrVElQn8c4CdfM/VUuuczmpLRDPbUSpi6ouS6mcWFZtEuWJltW	ACTIVE	0	\N	\N	2026-06-10 18:26:31.109	2026-06-10 18:26:31.109
cmq8eh5fj0007tk9wkld88rma	receptionist	Rekha Devi	rekha@gearup.local	9830078901	$2a$12$C9xwrVElQn8c4CdfM/VUuuczmpLRDPbUSpi6ouS6mcWFZtEuWJltW	ACTIVE	0	\N	\N	2026-06-10 18:26:31.109	2026-06-10 18:26:31.109
cmq8eh6fv0008tk9w1mzbe6c8	mechanic	Raju Mistri	raju@gearup.local	9830089012	$2a$12$C9xwrVElQn8c4CdfM/VUuuczmpLRDPbUSpi6ouS6mcWFZtEuWJltW	ACTIVE	0	\N	\N	2026-06-10 18:26:31.109	2026-06-10 18:26:31.109
cmq8eh4ei0006tk9wa9s35hy4	admin	Souvik Musib	souvik@gearup.local	9830012345	$2a$12$C9xwrVElQn8c4CdfM/VUuuczmpLRDPbUSpi6ouS6mcWFZtEuWJltW	ACTIVE	0	\N	2026-06-11 04:26:36.864	2026-06-10 18:26:31.109	2026-06-11 04:26:36.865
\.


--
-- Data for Name: AdminUserRole; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AdminUserRole" (id, "adminUserId", "roleId") FROM stdin;
cmq8eh7ft000atk9wqa0k6b2z	cmq8eh4ei0006tk9wa9s35hy4	cmq8eh0d60002tk9w9db4h81q
cmq8eh8gq000ctk9w5cza5c60	cmq8eh3dm0005tk9wa7k0g30s	cmq8eh0d60002tk9w9db4h81q
cmq8eh9gq000etk9wz5qcfnte	cmq8eh2dh0004tk9wdqt3azhy	cmq8eh0d60002tk9w9db4h81q
cmq8ehakq000gtk9w0kh9s9rc	cmq8eh5fj0007tk9wkld88rma	cmq8egzd30001tk9wn15m8rie
cmq8ehbkr000itk9wn1fovxu1	cmq8eh6fv0008tk9w1mzbe6c8	cmq8egycn0000tk9wa176ju1d
\.


--
-- Data for Name: AmcContract; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AmcContract" (id, "contractNumber", "customerId", "vehicleId", "amcPlanId", "startDate", "endDate", "totalServices", "servicesUsed", "servicesRemaining", "amountPaid", "paymentMode", "paymentDate", status, notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AmcPlan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AmcPlan" (id, "planName", description, "vehicleType", "ccRange", "durationMonths", "totalServicesIncluded", price, "coveredItems", exclusions, "isActive", "createdAt", "updatedAt") FROM stdin;
cmq95rpld000023mdg7rzokgj	GOLD		BIKE	350cc+	12	3	1485.00	\N		t	2026-06-11 07:10:37.385	2026-06-11 08:34:23.216
\.


--
-- Data for Name: AmcServiceUsage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AmcServiceUsage" (id, "amcContractId", "jobCardId", "serviceNumber", "serviceDate", notes, "createdAt") FROM stdin;
\.


--
-- Data for Name: Appointment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Appointment" (id, "referenceId", "serviceRequestId", "customerId", "vehicleId", "appointmentDate", "slotStart", "slotEnd", status, "bookingSource", "confirmationMode", "confirmedByAdminId", "assignedWorkerId", "bayId", "rescheduleReason", "cancellationReason", "createdAt", "updatedAt") FROM stdin;
cmq8ekn0i006atk9wy8y9f8e0	APT-2026-0001	cmq8ekhbe005qtk9w1o36z5lu	cmq8eih670027tk9wj6jp8eaq	cmq8eimv0002itk9wesbpxfyv	2026-06-01 18:29:10.441	2026-06-01 03:30:00	2026-06-01 04:00:00	COMPLETED	SEED	\N	\N	\N	\N	\N	\N	2026-06-10 18:29:17.826	2026-06-10 18:29:17.826
cmq8eknlp006ctk9w6piz9ehr	APT-2026-0002	cmq8ekhvm005stk9wnbhazp59	cmq8eihqb0028tk9w0gpzddyb	cmq8einf7002ktk9wwp4zuo1m	2026-06-03 18:29:10.441	2026-06-03 04:30:00	2026-06-03 05:00:00	COMPLETED	SEED	\N	\N	\N	\N	\N	\N	2026-06-10 18:29:18.589	2026-06-10 18:29:18.589
cmq8eko5s006etk9wow5fc8si	APT-2026-0003	cmq8ekifn005utk9wr34hxr5q	cmq8eiiah0029tk9wuc979hbk	cmq8einzb002mtk9w5hc9iaq4	2026-06-05 18:29:10.441	2026-06-05 05:30:00	2026-06-05 06:00:00	CHECKED_IN	SEED	\N	\N	\N	\N	\N	\N	2026-06-10 18:29:19.312	2026-06-10 18:29:19.312
cmq8ekopv006gtk9wbjltphnp	APT-2026-0004	cmq8ekizr005wtk9wizn7g537	cmq8eiiup002atk9wzpxd6gep	cmq8eiojm002otk9wdkyi20mn	2026-06-06 18:29:10.441	2026-06-06 06:30:00	2026-06-06 07:00:00	CONFIRMED	SEED	\N	\N	\N	\N	\N	\N	2026-06-10 18:29:20.035	2026-06-10 18:29:20.035
cmq8ekp9v006itk9wlw7pfv9r	APT-2026-0005	cmq8ekjjv005ytk9wy0yblsr6	cmq8eijet002btk9wwe3limxe	cmq8eip3o002qtk9w7se62f98	2026-06-07 18:29:10.441	2026-06-07 07:30:00	2026-06-07 08:00:00	CONFIRMED	SEED	\N	\N	\N	\N	\N	\N	2026-06-10 18:29:20.755	2026-06-10 18:29:20.755
cmq8ekpu6006ktk9wh30o4cte	APT-2026-0006	cmq8ekk3w0060tk9w3otdzaiq	cmq8eijys002ctk9w3hdj0k4k	cmq8eipnp002stk9wic4kau8j	2026-06-08 18:29:10.441	2026-06-08 08:30:00	2026-06-08 09:00:00	REQUESTED	SEED	\N	\N	\N	\N	\N	\N	2026-06-10 18:29:21.486	2026-06-10 18:29:21.486
cmq8ekqe9006mtk9w0iecdz5c	APT-2026-0007	cmq8ekko00062tk9wdi9x42lx	cmq8eikis002dtk9wda0pb6x4	cmq8eiq7r002utk9wm2cwfbr1	2026-06-09 18:29:10.441	2026-06-09 09:30:00	2026-06-09 10:00:00	CONFIRMED	SEED	\N	\N	\N	\N	\N	\N	2026-06-10 18:29:22.209	2026-06-10 18:29:22.209
cmq8fskk6000ai6kfwhophszx	APT-EKIXJNASUIDG	\N	cmq8eim6z002gtk9wm1yn00a2	cmq8eirvx0030tk9wvczo33g6	2026-06-20 00:00:00	2026-06-20 09:00:00	2026-06-20 10:00:00	CONFIRMED	WALK_IN	\N	cmq8eh4ei0006tk9wa9s35hy4	cmq8ej36f003atk9wucd5ypah	\N	\N	\N	2026-06-10 19:03:27.51	2026-06-10 19:03:27.51
\.


--
-- Data for Name: AppointmentSlotRule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AppointmentSlotRule" (id, "dayOfWeek", "openTime", "closeTime", "slotDurationMinutes", "maxCapacity", "isActive", "createdAt", "updatedAt") FROM stdin;
cmq8ejrxv004atk9w72n7mu17	1	09:00	18:00	30	3	t	2026-06-10 18:28:37.556	2026-06-10 18:28:37.556
cmq8ejsj6004btk9w3a2g5bas	2	09:00	18:00	30	3	t	2026-06-10 18:28:38.323	2026-06-10 18:28:38.323
cmq8ejt36004ctk9wwz0w5cam	3	09:00	18:00	30	3	t	2026-06-10 18:28:39.042	2026-06-10 18:28:39.042
cmq8ejtn4004dtk9wvyq7jwu0	4	09:00	18:00	30	3	t	2026-06-10 18:28:39.76	2026-06-10 18:28:39.76
cmq8eju74004etk9wfns1bqw7	5	09:00	18:00	30	3	t	2026-06-10 18:28:40.48	2026-06-10 18:28:40.48
cmq8ejur6004ftk9wg635h205	6	09:00	18:00	30	3	t	2026-06-10 18:28:41.202	2026-06-10 18:28:41.202
\.


--
-- Data for Name: BlockedSlot; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BlockedSlot" (id, "blockDate", "blockStartTime", "blockEndTime", "blockReason", "appliesToAll", "workerId", "bayId", "createdByAdminId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Customer" (id, "fullName", "phoneNumber", "alternatePhone", email, "addressLine1", "addressLine2", city, state, "postalCode", notes, source, "archivedAt", "createdAt", "updatedAt") FROM stdin;
cmq8eih670027tk9wj6jp8eaq	Rahim Sheikh	9831012345	\N	rahim@gmail.com	12 Park Street	\N	Kolkata	West Bengal	700001	\N	SEED	\N	2026-06-10 18:27:36.943	2026-06-10 18:27:36.943
cmq8eihqb0028tk9w0gpzddyb	Ananya Banerjee	9831023456	\N	ananya.b@gmail.com	45 GT Road	\N	Howrah	West Bengal	711101	\N	SEED	\N	2026-06-10 18:27:37.667	2026-06-10 18:27:37.667
cmq8eiiah0029tk9wuc979hbk	Subhash Mondal	9831034567	\N	\N	78 Jessore Road	\N	Barasat	West Bengal	700124	\N	SEED	\N	2026-06-10 18:27:38.393	2026-06-10 18:27:38.393
cmq8eiiup002atk9wzpxd6gep	Dipika Das	9831045678	\N	dipika.das@yahoo.com	AE Block, Sector 1	\N	Salt Lake	West Bengal	700091	\N	SEED	\N	2026-06-10 18:27:39.122	2026-06-10 18:27:39.122
cmq8eijet002btk9wwe3limxe	Rajesh Ghosh	9831056789	\N	\N	23 Nagerbazar	\N	Dum Dum	West Bengal	700028	\N	SEED	\N	2026-06-10 18:27:39.845	2026-06-10 18:27:39.845
cmq8eijys002ctk9w3hdj0k4k	Moumita Roy	9831067890	\N	moumita.r@gmail.com	56 Raja SC Mullick Road	\N	Jadavpur	West Bengal	700032	\N	SEED	\N	2026-06-10 18:27:40.565	2026-06-10 18:27:40.565
cmq8eikis002dtk9wda0pb6x4	Kamal Sarkar	9831078901	\N	\N	89 Diamond Harbour Road	\N	Behala	West Bengal	700034	\N	SEED	\N	2026-06-10 18:27:41.284	2026-06-10 18:27:41.284
cmq8eil2t002etk9w41q12clc	Taniya Biswas	9831089012	\N	taniya.b@outlook.com	Action Area 1	\N	New Town	West Bengal	700156	\N	SEED	\N	2026-06-10 18:27:42.005	2026-06-10 18:27:42.005
cmq8eilmx002ftk9w7fuqiqc1	Amit Halder	9831090123	\N	\N	34 SN Banerjee Road	\N	Barrackpore	West Bengal	700120	\N	SEED	\N	2026-06-10 18:27:42.729	2026-06-10 18:27:42.729
cmq8eim6z002gtk9wm1yn00a2	Suchitra Pal	9831001234	\N	suchitra.p@gmail.com	67 Narendrapur Road	\N	Garia	West Bengal	700084	\N	SEED	\N	2026-06-10 18:27:43.451	2026-06-10 18:27:43.451
cmq8yz8tu0002ei5io346nbz6	shanti ranjan kar	9832758529	\N	gearup.sgnk.ai@gmail.com	\N	\N	\N	\N	\N	\N	JOB_CARD_FORM	\N	2026-06-11 04:00:31.583	2026-06-11 04:00:31.583
cmq8zgfk10000c0uptfnpc77f	Tapas Tantubai	9851841943	\N	gearup.sgnk.ai@gmail.com	\N	\N	\N	\N	\N	\N	JOB_CARD_FORM	\N	2026-06-11 04:13:53.473	2026-06-11 04:13:53.473
cmq8zpxoa00004pnfqeua0fxf	Sudip Karmakar 	8016197754	\N	gearup.sgnk.ai@gmail.com	\N	\N	\N	\N	\N	\N	JOB_CARD_FORM	\N	2026-06-11 04:21:16.858	2026-06-11 04:21:16.858
cmq906y050000v0ipb3zif22u	Subrata Mandal	9800574142	\N	gearup.sgnk.ai@gmail.com	\N	\N	\N	\N	\N	\N	JOB_CARD_FORM	\N	2026-06-11 04:34:30.429	2026-06-11 04:34:30.429
cmq90aqgy000cv0ipx2o9ehnl	Biplab Pati	9647918638	\N	\N	\N	\N	\N	\N	\N	\N	JOB_CARD_FORM	\N	2026-06-11 04:37:27.298	2026-06-11 04:37:27.298
cmq90qcbi0000w352n3yauaux	Binit Das	9679828343	\N	gearup.sgnk.ai@gmail.com	\N	\N	\N	\N	\N	\N	JOB_CARD_FORM	\N	2026-06-11 04:49:35.455	2026-06-11 04:49:35.455
cmq9164ef000gw352im1qlnev	Sukhen 	8695291893	\N	gearup.sgnk.ai@gmail.com	\N	\N	\N	\N	\N	\N	JOB_CARD_FORM	\N	2026-06-11 05:01:51.682	2026-06-11 05:01:51.682
cmq92syu40000q3jpsrf3z87h	Sumanta Mukherjee 	9064458228	\N	\N	\N	\N	\N	\N	\N	\N	JOB_CARD_FORM	\N	2026-06-11 05:47:37.177	2026-06-11 05:47:37.177
cmq9321y4000cq3jpjjbuad34	Debabrata Patra	7407944841	\N	\N	\N	\N	\N	\N	\N	\N	JOB_CARD_FORM	\N	2026-06-11 05:54:41.112	2026-06-11 05:54:41.112
cmq93vtem000epdphfnndmaf5	ABIR DASMODAK 	9832201386	\N	gearup.sgnk.ai@gmail.com	\N	\N	\N	\N	\N	\N	JOB_CARD_FORM	\N	2026-06-11 06:17:49.722	2026-06-11 06:17:49.722
cmq93zrzr000qpdph0uog4py3	GOURAV BHATTACHARYAA	7550883795	\N	gearup.sgnk.ai@gmail.com	\N	\N	\N	\N	\N	\N	JOB_CARD_FORM	\N	2026-06-11 06:20:54.515	2026-06-11 06:20:54.515
cmq94p3920000qplb19fz53pl	SANAT BOSE	8670518015	\N	\N	\N	\N	\N	\N	\N	\N	JOB_CARD_FORM	\N	2026-06-11 06:40:35.506	2026-06-11 06:40:35.506
cmq95ac2j000d8xw0nzx65tyh	PRADIP KUMAR MODAK	9933593493	\N	gearup.sgnk.ai@gmail.com	\N	\N	\N	\N	\N	\N	JOB_CARD_FORM	\N	2026-06-11 06:57:06.711	2026-06-11 06:57:06.711
\.


--
-- Data for Name: Expense; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Expense" (id, "expenseDate", "categoryId", title, amount, "vendorName", "paymentMode", "referenceNumber", notes, "createdByAdminId", "createdAt", "updatedAt") FROM stdin;
cmq8ek60p004wtk9wcmmby0td	2026-04-01 00:00:00	cmq8ek205004rtk9wt2uohlhj	April Shop Rent	25000.00	Landlord - Ashok Dutta	BANK_TRANSFER	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:28:55.802	2026-06-10 18:28:55.802
cmq8ek6l1004ytk9wufcdwslm	2026-04-05 00:00:00	cmq8ek0zv004qtk9wqfibd399	Electricity Bill March	4500.00	CESC	UPI	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:28:56.533	2026-06-10 18:28:56.533
cmq8ek7530050tk9w0hw4hemb	2026-04-08 00:00:00	cmq8ek50j004utk9wj3df7vqt	New Torque Wrench	3200.00	Kolkata Tools Mart	CASH	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:28:57.256	2026-06-10 18:28:57.256
cmq8ek7pn0052tk9wxxye91tt	2026-04-10 00:00:00	cmq8ek40g004ttk9wj1soxhmp	Drinking Water Cans	600.00	Bisleri Dealer	CASH	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:28:57.995	2026-06-10 18:28:57.995
cmq8ek89u0054tk9w3dzv13ix	2026-04-30 00:00:00	cmq8ek30d004stk9wf25b8usz	Raju Salary April	18000.00	Raju Mistri	BANK_TRANSFER	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:28:58.722	2026-06-10 18:28:58.722
cmq8ek8tx0056tk9wg6hdm9q1	2026-04-30 00:00:00	cmq8ek30d004stk9wf25b8usz	Bablu Salary April	15000.00	Bablu Das	BANK_TRANSFER	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:28:59.445	2026-06-10 18:28:59.445
cmq8ek9dy0058tk9wau2ld9iu	2026-04-12 00:00:00	cmq8ek40g004ttk9wj1soxhmp	Chain Cleaning Spray	450.00	Amazon	UPI	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:29:00.166	2026-06-10 18:29:00.166
cmq8ek9xz005atk9we3l6d0tn	2026-04-15 00:00:00	cmq8ek50j004utk9wj3df7vqt	New Air Compressor	8500.00	Howrah Industrial	CARD	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:29:00.887	2026-06-10 18:29:00.887
cmq8ekam2005ctk9w8q61wdhz	2026-04-18 00:00:00	cmq8ek40g004ttk9wj1soxhmp	Internet Bill	1200.00	Airtel	UPI	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:29:01.609	2026-06-10 18:29:01.609
cmq8ekb63005etk9wcm1s2840	2026-04-30 00:00:00	cmq8ek30d004stk9wf25b8usz	Tapan Salary April	15000.00	Tapan Karmakar	BANK_TRANSFER	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:29:02.475	2026-06-10 18:29:02.475
\.


--
-- Data for Name: ExpenseCategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ExpenseCategory" (id, "categoryName", description) FROM stdin;
cmq8ek0zv004qtk9wqfibd399	Electricity	Power bills
cmq8ek205004rtk9wt2uohlhj	Rent	Shop rent
cmq8ek30d004stk9wf25b8usz	Salary	Worker salaries
cmq8ek40g004ttk9wj1soxhmp	Miscellaneous	Other expenses
cmq8ek50j004utk9wj3df7vqt	Tools & Equipment	Workshop tools
\.


--
-- Data for Name: Holiday; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Holiday" (id, "holidayName", "holidayDate", "holidayType", "isFullDay", "startTime", "endTime", notes, "createdAt") FROM stdin;
cmq8ejvbf004gtk9wrnpmsji0	Republic Day	2026-01-26 00:00:00	PUBLIC_HOLIDAY	t	\N	\N	\N	2026-06-10 18:28:41.931
cmq8ejvvo004htk9wzvioy7g7	Holi	2026-03-17 00:00:00	PUBLIC_HOLIDAY	t	\N	\N	\N	2026-06-10 18:28:42.66
cmq8ejwfo004itk9wahzusjsx	Independence Day	2026-08-15 00:00:00	PUBLIC_HOLIDAY	t	\N	\N	\N	2026-06-10 18:28:43.38
cmq8ejwzn004jtk9w2zmexg5f	Durga Puja Saptami	2026-10-14 00:00:00	PUBLIC_HOLIDAY	t	\N	\N	\N	2026-06-10 18:28:44.099
cmq8ejxjs004ktk9wyacq10lc	Durga Puja Ashtami	2026-10-15 00:00:00	PUBLIC_HOLIDAY	t	\N	\N	\N	2026-06-10 18:28:44.824
cmq8ejy3r004ltk9wjojmbl6x	Durga Puja Navami	2026-10-16 00:00:00	PUBLIC_HOLIDAY	t	\N	\N	\N	2026-06-10 18:28:45.544
cmq8ejyrs004mtk9wo5jgfku6	Durga Puja Dashami	2026-10-17 00:00:00	PUBLIC_HOLIDAY	t	\N	\N	\N	2026-06-10 18:28:46.265
cmq8ejzbr004ntk9we8ogvjc5	Kali Puja	2026-11-04 00:00:00	PUBLIC_HOLIDAY	t	\N	\N	\N	2026-06-10 18:28:47.128
cmq8ejzvs004otk9wyhrke7f0	Christmas	2026-12-25 00:00:00	PUBLIC_HOLIDAY	t	\N	\N	\N	2026-06-10 18:28:47.848
cmq8ek0fu004ptk9w29w38xj5	Annual Maintenance	2026-06-15 00:00:00	MAINTENANCE_SHUTDOWN	t	\N	\N	Shop deep cleaning & equipment maintenance	2026-06-10 18:28:48.571
\.


--
-- Data for Name: InventoryCategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."InventoryCategory" (id, "categoryName", description) FROM stdin;
cmq8ej3qj003btk9w23gzbga2	Engine Parts	Pistons, rings, gaskets
cmq8ej4qt003ctk9w5h9t0yhe	Brake Parts	Pads, shoes, discs, cables
cmq8ej5r0003dtk9whbsp6h2n	Oils & Lubricants	Engine oil, chain lube, grease
cmq8ej6r4003etk9w9ne0v7qc	Electrical	Bulbs, wiring, CDI, regulators
cmq8ej7r8003ftk9wprw9yud8	Filters	Air, oil, fuel filters
cmq8ej8rb003gtk9wa7f0p24i	Tyres & Tubes	Tyres, tubes, rim tapes
cmq8ej9rc003htk9wetckn663	Bearings	Wheel, steering, crank bearings
cmq8ejavf003itk9wledv4req	Consumables	Spark plugs, fuses, clips
cmq8ejbvh003jtk9w7qb9sm0w	Chain & Sprocket	Chains, sprockets, chain sets
cmq8ejcvj003ktk9w09dt9laq	Body Parts	Fairings, mirrors, levers
\.


--
-- Data for Name: InventoryItem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."InventoryItem" (id, sku, "itemName", "categoryId", "supplierId", brand, description, "compatibleVehicleTypes", unit, "taxRate", "costPrice", mrp, "sellingPrice", "discountPercent", "quantityInStock", "reservedQuantity", "reorderLevel", "reorderQuantity", "storageLocation", barcode, "isActive", "variablePrice", "isBranded", "createdAt", "updatedAt") FROM stdin;
cmq8ejh7y003rtk9wiwqig5qo	ENG-001	Engine Oil 10W-30 (1L)	cmq8ej5r0003dtk9whbsp6h2n	cmq8ejefl003mtk9widwsf9n5	\N	\N	\N	litre	0.00	280.00	\N	350.00	\N	50.00	0.00	10.00	\N	\N	\N	t	f	t	2026-06-10 18:28:23.663	2026-06-10 18:28:23.663
cmq8ejic9003ttk9w7qphf54b	ENG-002	Piston Ring Set	cmq8ej3qj003btk9w23gzbga2	cmq8ejdvj003ltk9wutv1pn7j	\N	\N	\N	set	0.00	450.00	\N	650.00	\N	20.00	0.00	5.00	\N	\N	\N	t	f	t	2026-06-10 18:28:25.113	2026-06-10 18:28:25.113
cmq8ejjgc003vtk9wbgrnnl29	BRK-001	Front Brake Pad Set	cmq8ej4qt003ctk9w5h9t0yhe	cmq8ejdvj003ltk9wutv1pn7j	\N	\N	\N	set	0.00	180.00	\N	280.00	\N	30.00	0.00	8.00	\N	\N	\N	t	f	t	2026-06-10 18:28:26.556	2026-06-10 18:28:26.556
cmq8ejkkh003xtk9w5u32e7vk	BRK-002	Clutch Cable	cmq8ej4qt003ctk9w5h9t0yhe	cmq8ejezj003ntk9wdn9jtmn1	\N	\N	\N	pcs	0.00	120.00	\N	200.00	\N	25.00	0.00	5.00	\N	\N	\N	t	f	t	2026-06-10 18:28:28.002	2026-06-10 18:28:28.002
cmq8ejlol003ztk9we0kr5zbt	ELC-001	Headlight Bulb H4	cmq8ej6r4003etk9w9ne0v7qc	cmq8ejezj003ntk9wdn9jtmn1	\N	\N	\N	pcs	0.00	80.00	\N	150.00	\N	40.00	0.00	10.00	\N	\N	\N	t	f	t	2026-06-10 18:28:29.446	2026-06-10 18:28:29.446
cmq8ejmwl0041tk9wnjdxfhcu	CHN-001	Chain Sprocket Kit	cmq8ejbvh003jtk9w7qb9sm0w	cmq8ejg3q003ptk9wvtgfel24	\N	\N	\N	set	0.00	800.00	\N	1200.00	\N	15.00	0.00	3.00	\N	\N	\N	t	f	t	2026-06-10 18:28:30.886	2026-06-10 18:28:30.886
cmq8ejo0s0043tk9wk2mq1a3s	TYR-001	Front Tyre 80/100-17	cmq8ej8rb003gtk9wa7f0p24i	cmq8ejfjk003otk9wp70gz2na	\N	\N	\N	pcs	0.00	1200.00	\N	1600.00	\N	10.00	0.00	3.00	\N	\N	\N	t	f	t	2026-06-10 18:28:32.476	2026-06-10 18:28:32.476
cmq8ejp530045tk9wx5vwym0d	FLT-001	Air Filter Element	cmq8ej7r8003ftk9wprw9yud8	cmq8ejdvj003ltk9wutv1pn7j	\N	\N	\N	pcs	0.00	150.00	\N	250.00	\N	35.00	0.00	8.00	\N	\N	\N	t	f	t	2026-06-10 18:28:33.927	2026-06-10 18:28:33.927
cmq8ejq970047tk9wtnja1wrz	BRG-001	Wheel Bearing 6301	cmq8ej9rc003htk9wetckn663	cmq8ejezj003ntk9wdn9jtmn1	\N	\N	\N	pcs	0.00	90.00	\N	160.00	\N	20.00	0.00	5.00	\N	\N	\N	t	f	t	2026-06-10 18:28:35.371	2026-06-10 18:28:35.371
cmq8ejrdm0049tk9wb4xiv8hk	CON-001	Spark Plug (NGK)	cmq8ejavf003itk9wledv4req	cmq8ejg3q003ptk9wvtgfel24	\N	\N	\N	pcs	0.00	60.00	\N	120.00	\N	60.00	0.00	15.00	\N	\N	\N	t	f	t	2026-06-10 18:28:36.827	2026-06-10 18:28:36.827
\.


--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Invoice" (id, "invoiceNumber", "customerId", "vehicleId", "jobCardId", "appointmentId", "invoiceDate", "dueDate", subtotal, "discountType", "discountValue", "discountAmount", "taxTotal", "grandTotal", "amountPaid", "amountDue", "paymentStatus", "invoiceStatus", notes, "finalizedAt", "createdByAdminId", "createdAt", "updatedAt") FROM stdin;
cmq8ellq6009ctk9wms0m2olr	INV-2026-0001	cmq8eih670027tk9wj6jp8eaq	cmq8eimv0002itk9wesbpxfyv	cmq8ekqyd006otk9w8ly7z8oq	\N	2026-06-02 18:29:10.441	\N	1050.00	\N	\N	0.00	189.00	1239.00	1239.00	0.00	PAID	FINALIZED	\N	2026-06-02 18:29:10.441	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:30:02.814	2026-06-10 18:30:02.814
cmq8elnnb009htk9wdfl8o5cw	INV-2026-0002	cmq8eihqb0028tk9w0gpzddyb	cmq8einf7002ktk9wwp4zuo1m	cmq8eks30006qtk9w3k37670e	\N	2026-06-04 18:29:10.441	\N	1350.00	\N	\N	0.00	243.00	1593.00	796.50	796.50	PARTIALLY_PAID	FINALIZED	\N	2026-06-04 18:29:10.441	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:30:05.303	2026-06-10 18:30:05.303
cmq8zhnej0009c0upr3cpkxqa	INV-O7IRQ66H	cmq8zgfk10000c0uptfnpc77f	cmq8zgx6t0004c0up8blgf3a3	cmq8zhndk0008c0upmdloj9do	\N	2026-06-11 04:14:50.299	\N	0.00	\N	\N	0.00	0.00	0.00	0.00	0.00	UNPAID	DRAFT	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 04:14:50.3	2026-06-11 04:14:50.3
cmq90967f0009v0ip7g7euqvj	INV-HOQ5H3J7	cmq906y050000v0ipb3zif22u	cmq907hjc0004v0ipiiop2nqj	cmq9096670008v0ipef6ae0m3	\N	2026-06-11 04:36:14.378	\N	0.00	\N	\N	0.00	0.00	0.00	0.00	0.00	UNPAID	DRAFT	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 04:36:14.379	2026-06-11 04:36:14.379
cmq90e6du000lv0ip3ewuut5w	INV-UMUT3RAL	cmq90aqgy000cv0ipx2o9ehnl	cmq90b5ad000gv0ip606qeqm6	cmq90e6ci000kv0ipbrl8rywb	\N	2026-06-11 04:40:07.889	\N	0.00	\N	\N	0.00	0.00	0.00	0.00	0.00	UNPAID	DRAFT	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 04:40:07.89	2026-06-11 04:40:07.89
cmq90rmlw0009w352mswdp0ec	INV-V9QB2XFJ	cmq90qcbi0000w352n3yauaux	cmq90qukt0004w352hl9rne4u	cmq90rmkl0008w352tck2ie43	\N	2026-06-11 04:50:35.444	\N	0.00	\N	\N	0.00	0.00	0.00	0.00	0.00	UNPAID	DRAFT	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 04:50:35.445	2026-06-11 04:50:35.445
cmq92yrnf0009q3jpk0m70ift	INV-4A4C9U79	cmq92syu40000q3jpsrf3z87h	cmq92ucij0004q3jp9rbw3nli	cmq92yrma0008q3jpgvtowqan	\N	2026-06-11 05:52:07.802	\N	0.00	\N	\N	0.00	0.00	0.00	0.00	0.00	UNPAID	DRAFT	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 05:52:07.803	2026-06-11 05:52:07.803
cmq916ux6000pw3520720u1ao	INV-RW15I7UQ	cmq9164ef000gw352im1qlnev	cmq916mf0000kw352sukhqh2a	cmq916uvk000ow352jjiacaui	\N	2026-06-11 05:02:26.058	\N	49.00	\N	\N	0.00	0.00	49.00	49.00	0.00	PAID	FINALIZED	\N	2026-06-11 08:36:05.922	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 05:02:26.059	2026-06-11 08:36:10.149
cmq95bak6000m8xw0p6gsxrj9	INV-Z9TJ713L	cmq95ac2j000d8xw0nzx65tyh	cmq95awcf000h8xw0bjuy7tzj	cmq95baj2000l8xw07dglk68b	\N	2026-06-11 06:57:51.414	\N	1485.00	\N	\N	0.00	0.00	1485.00	0.00	1485.00	UNPAID	DRAFT	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 06:57:51.415	2026-06-11 08:46:30.343
cmq8zs5rz0002ogmd9zwxup9e	INV-GUN94L0J	cmq8zpxoa00004pnfqeua0fxf	cmq8zqd3m00044pnf93zcloss	cmq8zs5qt0001ogmd2g7onc6s	\N	2026-06-11 04:23:00.67	\N	74.00	\N	\N	0.00	0.00	74.00	74.00	0.00	PAID	FINALIZED	\N	2026-06-11 06:11:41.12	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 04:23:00.671	2026-06-11 06:11:46.628
cmq93x2d5000npdphfa8xr8sv	INV-3OYXH1BR	cmq93vtem000epdphfnndmaf5	cmq93wc0i000ipdphqz3sbeul	cmq93x2bu000mpdphexus3983	\N	2026-06-11 06:18:47.993	\N	0.00	\N	\N	0.00	0.00	0.00	0.00	0.00	UNPAID	DRAFT	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 06:18:47.994	2026-06-11 06:18:47.994
cmq940qw5000zpdph45hr47mc	INV-KH0UBIS5	cmq93zrzr000qpdph0uog4py3	cmq9407qc000updphadqqd9b2	cmq940qut000ypdphcqnz22b2	\N	2026-06-11 06:21:39.748	\N	0.00	\N	\N	0.00	0.00	0.00	0.00	0.00	UNPAID	DRAFT	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 06:21:39.749	2026-06-11 06:21:39.749
cmq8z0yke000bei5ikzc3h6wc	INV-2KA5S2UQ	cmq8yz8tu0002ei5io346nbz6	cmq8z0hq40006ei5ifaqsfpcr	cmq8z0yj4000aei5ir1tgdsfe	\N	2026-06-11 04:01:51.613	\N	796.50	\N	\N	0.00	0.00	797.00	0.00	797.00	UNPAID	FINALIZED	\N	2026-06-11 08:18:11.772	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 04:01:51.614	2026-06-11 08:18:11.773
cmq94q77b0009qplbs2jqz4au	INV-AYC37HTG	cmq94p3920000qplb19fz53pl	cmq94px7i0004qplberzhfail	cmq94q7600008qplbsmhf4nq9	\N	2026-06-11 06:41:27.287	\N	750.00	\N	\N	0.00	0.00	750.00	750.00	0.00	PAID	FINALIZED	\N	2026-06-11 06:43:19.446	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 06:41:27.288	2026-06-11 06:47:43.364
cmq9345uu000lq3jpvlx0szcg	INV-Q63ZMQVH	cmq9321y4000cq3jpjjbuad34	cmq932ic7000gq3jprhxini79	cmq9345tu000kq3jpytm93djn	\N	2026-06-11 05:56:19.494	\N	49.00	\N	\N	0.00	0.00	49.00	49.00	0.00	PAID	FINALIZED	\N	2026-06-11 06:55:50.3	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 05:56:19.495	2026-06-11 06:55:54.265
\.


--
-- Data for Name: InvoiceLineItem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."InvoiceLineItem" (id, "invoiceId", "lineType", "referenceItemId", description, quantity, "unitPrice", "discountPercent", "taxRate", "taxAmount", "lineTotal", "sortOrder") FROM stdin;
cmq8ellq6009dtk9w45b5tta8	cmq8ellq6009ctk9wms0m2olr	PART	\N	Engine Oil 10W-30 (1L)	1.00	350.00	0.00	18.00	63.00	413.00	0
cmq8ellq6009etk9w5u0k7r1g	cmq8ellq6009ctk9wms0m2olr	PART	\N	Clutch Cable	2.00	200.00	0.00	18.00	72.00	472.00	1
cmq8ellq6009ftk9w1j4sd3mr	cmq8ellq6009ctk9wms0m2olr	LABOR	\N	Labor — Raju Mistri	1.00	300.00	0.00	18.00	54.00	354.00	2
cmq8elnnb009itk9wy4a5amo6	cmq8elnnb009htk9wdfl8o5cw	PART	\N	Piston Ring Set	1.00	650.00	0.00	18.00	117.00	767.00	0
cmq8elnnb009jtk9w247m4148	cmq8elnnb009htk9wdfl8o5cw	PART	\N	Headlight Bulb H4	2.00	150.00	0.00	18.00	54.00	354.00	1
cmq8elnnb009ktk9w3j6pk5jb	cmq8elnnb009htk9wdfl8o5cw	LABOR	\N	Labor — Bablu Das	1.00	400.00	0.00	18.00	72.00	472.00	2
cmq93no4l0001pdph8b908yue	cmq8zs5rz0002ogmd9zwxup9e	SERVICE_CHARGE	\N	CHAIN CLEAN	1.00	25.00	0.00	0.00	0.00	25.00	0
cmq93nv8s0007pdphv6zc78p8	cmq8zs5rz0002ogmd9zwxup9e	SERVICE_CHARGE	\N	FOAM WASH	1.00	49.00	0.00	0.00	0.00	49.00	0
cmq94s1740001cw11qoiyw162	cmq94q77b0009qplbs2jqz4au	CUSTOM_CHARGE	\N	CASTROL 10W30	1.00	400.00	5.00	0.00	0.00	380.00	0
cmq94s79d00018xw0dmzleeh1	cmq94q77b0009qplbs2jqz4au	SERVICE_CHARGE	\N	General Service	1.00	370.00	0.00	0.00	0.00	370.00	0
cmq958ned000ecw11e0yg5qgk	cmq9345uu000lq3jpvlx0szcg	SERVICE_CHARGE	\N	FOAM WASH	1.00	49.00	0.00	0.00	0.00	49.00	0
cmq983r9f00018ev6fdrk3tiy	cmq8z0yke000bei5ikzc3h6wc	CUSTOM_CHARGE	\N	Labour charges 	1.00	350.00	0.00	0.00	0.00	350.00	0
cmq9865m2000f8ev6loxjroz4	cmq8z0yke000bei5ikzc3h6wc	SERVICE_CHARGE	\N	Activ Castrol 20w40 	1.00	470.00	5.00	0.00	0.00	446.50	0
cmq98tl4i000zuif55kd3y0dr	cmq916ux6000pw3520720u1ao	SERVICE_CHARGE	\N	foam wash 	1.00	49.00	0.00	0.00	0.00	49.00	0
cmq9970kq0003e1hksek0oc19	cmq95bak6000m8xw0p6gsxrj9	AMC	cmq95rpld000023mdg7rzokgj	AMC — GOLD (350cc+)	1.00	1485.00	0.00	0.00	0.00	1485.00	0
\.


--
-- Data for Name: JobCard; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobCard" (id, "jobCardNumber", "appointmentId", "serviceRequestId", "customerId", "vehicleId", "intakeDate", "odometerAtIntake", "fuelIndicator", "estimatedDeliveryAt", "actualDeliveryAt", "issueSummary", "customerComplaints", "diagnosisNotes", "estimateNotes", "approvalStatus", priority, status, "assignedServiceManagerId", "estimatedPartsCost", "estimatedLaborCost", "estimatedOtherCost", "estimatedTotal", "finalPartsCost", "finalLaborCost", "finalOtherCost", "finalTotal", "customerVisibleNotes", "internalNotes", "estimateToken", "estimateTokenExpiresAt", "estimateRevision", "createdAt", "updatedAt") FROM stdin;
cmq8ekqyd006otk9w8ly7z8oq	JC-2026-0001	cmq8ekn0i006atk9wy8y9f8e0	cmq8ekhbe005qtk9w1o36z5lu	cmq8eih670027tk9wj6jp8eaq	cmq8eimv0002itk9wesbpxfyv	2026-06-01 18:29:10.441	32982	\N	\N	2026-06-03 18:29:10.441	Engine making knocking sound at high RPM	\N	\N	\N	PENDING	HIGH	DELIVERED	\N	500.00	300.00	0.00	800.00	500.00	300.00	0.00	800.00	\N	\N	\N	\N	\N	2026-06-10 18:29:22.933	2026-06-10 18:29:22.933
cmq8eks30006qtk9w3k37670e	JC-2026-0002	cmq8eknlp006ctk9w6piz9ehr	cmq8ekhvm005stk9wnbhazp59	cmq8eihqb0028tk9w0gpzddyb	cmq8einf7002ktk9wwp4zuo1m	2026-06-03 18:29:10.441	11899	\N	\N	\N	Regular 5000km service due, oil change needed	\N	\N	\N	PENDING	\N	CLOSED	\N	700.00	400.00	0.00	1100.00	700.00	400.00	0.00	1100.00	\N	\N	\N	\N	\N	2026-06-10 18:29:24.397	2026-06-10 18:29:24.397
cmq8ekt7e006stk9w2kuaudmw	JC-2026-0003	cmq8eko5s006etk9wow5fc8si	cmq8ekifn005utk9wr34hxr5q	cmq8eiiah0029tk9wuc979hbk	cmq8einzb002mtk9w5hc9iaq4	2026-06-05 18:29:10.441	14717	\N	\N	\N	Front brake not gripping properly, squeaking noise	\N	\N	\N	PENDING	\N	WORK_IN_PROGRESS	\N	900.00	500.00	0.00	1400.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-10 18:29:25.85	2026-06-10 18:29:25.85
cmq8ekubt006utk9w182c6uoa	JC-2026-0004	cmq8ekopv006gtk9wbjltphnp	cmq8ekizr005wtk9wizn7g537	cmq8eiiup002atk9wzpxd6gep	cmq8eiojm002otk9wdkyi20mn	2026-06-06 18:29:10.441	16690	\N	\N	\N	Headlight flickering, battery draining overnight	\N	\N	\N	PENDING	\N	ESTIMATE_PREPARED	\N	1100.00	600.00	0.00	1700.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-10 18:29:27.305	2026-06-10 18:29:27.305
cmq8ekvhp006wtk9w117gjwjt	JC-2026-0005	cmq8ekp9v006itk9wlw7pfv9r	cmq8ekjjv005ytk9wy0yblsr6	cmq8eijet002btk9wwe3limxe	cmq8eip3o002qtk9w7se62f98	2026-06-07 18:29:10.441	17915	\N	\N	\N	Chain loose and making noise, sprocket teeth worn	\N	\N	\N	PENDING	\N	CREATED	\N	1300.00	700.00	0.00	2000.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-10 18:29:28.813	2026-06-10 18:29:28.813
cmq8zhndk0008c0upmdloj9do	JC-R225V1C3	\N	\N	cmq8zgfk10000c0uptfnpc77f	cmq8zgx6t0004c0up8blgf3a3	2026-06-11 04:14:50.257	9506	1/4	\N	\N	General Servicing \nFront brake check \nFoam wash		\N	\N	PENDING		CREATED	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-11 04:14:50.258	2026-06-11 04:14:50.258
cmq9096670008v0ipef6ae0m3	JC-JO9QW52H	\N	\N	cmq906y050000v0ipb3zif22u	cmq907hjc0004v0ipiiop2nqj	2026-06-11 04:36:14.324	5299	1/4	\N	\N	Mileage issue\nMobil check\nFoam wash 		\N	\N	PENDING		CREATED	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-11 04:36:14.324	2026-06-11 04:36:14.324
cmq90e6ci000kv0ipbrl8rywb	JC-LGM922DV	\N	\N	cmq90aqgy000cv0ipx2o9ehnl	cmq90b5ad000gv0ip606qeqm6	2026-06-11 04:40:07.81	14605	E	\N	\N	General Servicing, Rear break loose, Foam Wash, Engine Oil check, Gear Check	Scratch 	\N	\N	PENDING		CREATED	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-11 04:40:07.811	2026-06-11 04:40:07.811
cmq90rmkl0008w352tck2ie43	JC-F2A4VYXN	\N	\N	cmq90qcbi0000w352n3yauaux	cmq90qukt0004w352hl9rne4u	2026-06-11 04:50:35.378	9686	1/2	\N	\N	General Servicing \nSelf check\nBearing check\nMobil check		\N	\N	PENDING		CREATED	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-11 04:50:35.379	2026-06-11 04:50:35.379
cmq8z0yj4000aei5ir1tgdsfe	JC-QC88LOT4	\N	\N	cmq8yz8tu0002ei5io346nbz6	cmq8z0hq40006ei5ifaqsfpcr	2026-06-11 04:01:51.56	5668	1/2	\N	\N	general servicing mobil change castrol		\N	\N	PENDING		WORK_IN_PROGRESS	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-11 04:01:51.561	2026-06-11 04:58:28.501
cmq92yrma0008q3jpgvtowqan	JC-CGWF0WXP	\N	\N	cmq92syu40000q3jpsrf3z87h	cmq92ucij0004q3jp9rbw3nli	2026-06-11 05:52:07.756	43371	E	\N	\N	Mobil Change Castrol, Clutch Adjust, Chain Adjust, Air Filter Check, General Servicing 		\N	\N	PENDING		CREATED	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-11 05:52:07.757	2026-06-11 05:52:07.757
cmq8zs5qt0001ogmd2g7onc6s	JC-4AQPSIXJ	\N	\N	cmq8zpxoa00004pnfqeua0fxf	cmq8zqd3m00044pnf93zcloss	2026-06-11 04:23:00.624	9865	1/4	\N	2026-06-11 06:11:46.639	Foam Wash \nChain clean \n		\N	\N	PENDING		DELIVERED	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-11 04:23:00.625	2026-06-11 06:11:46.64
cmq93x2bu000mpdphexus3983	JC-G6ORWAI0	\N	\N	cmq93vtem000epdphfnndmaf5	cmq93wc0i000ipdphqz3sbeul	2026-06-11 06:18:47.933	5662	1/2	\N	\N	FOAM WASH 		\N	\N	PENDING		CREATED	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-11 06:18:47.933	2026-06-11 06:18:47.933
cmq940qut000ypdphcqnz22b2	JC-9D63LOKF	\N	\N	cmq93zrzr000qpdph0uog4py3	cmq9407qc000updphadqqd9b2	2026-06-11 06:21:39.66	5656	1/2	\N	\N	NORMAL WASH		\N	\N	PENDING		CREATED	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-11 06:21:39.663	2026-06-11 06:21:39.663
cmq94q7600008qplbsmhf4nq9	JC-NHYTALAW	\N	\N	cmq94p3920000qplb19fz53pl	cmq94px7i0004qplberzhfail	2026-06-11 06:41:27.235	8642	1/4	\N	2026-06-11 06:47:43.372	GENERAL SERVICING 		\N	\N	PENDING		DELIVERED	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-11 06:41:27.236	2026-06-11 06:47:43.373
cmq9345tu000kq3jpytm93djn	JC-D5SCQAQY	\N	\N	cmq9321y4000cq3jpjjbuad34	cmq932ic7000gq3jprhxini79	2026-06-11 05:56:19.45	57742	3/4	\N	2026-06-11 06:55:54.274	Foam Wash 		\N	\N	PENDING		DELIVERED	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-11 05:56:19.451	2026-06-11 06:55:54.275
cmq95baj2000l8xw07dglk68b	JC-HRQR3L5S	\N	\N	cmq95ac2j000d8xw0nzx65tyh	cmq95awcf000h8xw0bjuy7tzj	2026-06-11 06:57:51.363	5565	1/4	\N	\N	FOAM WASH SILICON POLISH		\N	\N	PENDING		CREATED	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-11 06:57:51.364	2026-06-11 06:58:47.899
cmq916uvk000ow352jjiacaui	JC-WVPBWGSW	\N	\N	cmq9164ef000gw352im1qlnev	cmq916mf0000kw352sukhqh2a	2026-06-11 05:02:25.983	68062	1/2	\N	2026-06-11 08:36:10.162	Foam wash 		\N	\N	PENDING		DELIVERED	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2026-06-11 05:02:25.984	2026-06-11 08:36:10.163
\.


--
-- Data for Name: JobCardPart; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobCardPart" (id, "jobCardId", "inventoryItemId", "requiredQty", "reservedQty", "consumedQty", "unitPrice", notes, "createdAt", "updatedAt") FROM stdin;
cmq8elfd1008stk9wovwttobh	cmq8ekqyd006otk9w8ly7z8oq	cmq8ejh7y003rtk9wiwqig5qo	1.00	0.00	0.00	350.00	\N	2026-06-10 18:29:54.565	2026-06-10 18:29:54.565
cmq8elfxi008utk9w5b71xbm3	cmq8ekqyd006otk9w8ly7z8oq	cmq8ejkkh003xtk9w5u32e7vk	2.00	0.00	0.00	200.00	\N	2026-06-10 18:29:55.302	2026-06-10 18:29:55.302
cmq8elghk008wtk9wg7iu5snz	cmq8eks30006qtk9w3k37670e	cmq8ejic9003ttk9w7qphf54b	1.00	0.00	0.00	650.00	\N	2026-06-10 18:29:56.024	2026-06-10 18:29:56.024
cmq8elh1k008ytk9wmzk41glo	cmq8eks30006qtk9w3k37670e	cmq8ejlol003ztk9we0kr5zbt	2.00	0.00	0.00	150.00	\N	2026-06-10 18:29:56.745	2026-06-10 18:29:56.745
cmq8elhln0090tk9w186n7eay	cmq8ekt7e006stk9w2kuaudmw	cmq8ejjgc003vtk9wbgrnnl29	1.00	0.00	0.00	280.00	\N	2026-06-10 18:29:57.467	2026-06-10 18:29:57.467
cmq8eli5y0092tk9w7m6ztzvp	cmq8ekt7e006stk9w2kuaudmw	cmq8ejmwl0041tk9wnjdxfhcu	2.00	0.00	0.00	1200.00	\N	2026-06-10 18:29:58.199	2026-06-10 18:29:58.199
cmq8eliq00094tk9wg5q0ixu9	cmq8ekubt006utk9w182c6uoa	cmq8ejkkh003xtk9w5u32e7vk	1.00	0.00	0.00	200.00	\N	2026-06-10 18:29:58.921	2026-06-10 18:29:58.921
cmq8elja00096tk9wknntzw2n	cmq8ekubt006utk9w182c6uoa	cmq8ejo0s0043tk9wk2mq1a3s	2.00	0.00	0.00	1600.00	\N	2026-06-10 18:29:59.64	2026-06-10 18:29:59.64
cmq8elju20098tk9wz2scvx8v	cmq8ekvhp006wtk9w117gjwjt	cmq8ejlol003ztk9we0kr5zbt	1.00	0.00	0.00	150.00	\N	2026-06-10 18:30:00.363	2026-06-10 18:30:00.363
cmq8elke2009atk9wiudknqf8	cmq8ekvhp006wtk9w117gjwjt	cmq8ejp530045tk9wx5vwym0d	2.00	0.00	0.00	250.00	\N	2026-06-10 18:30:01.082	2026-06-10 18:30:01.082
\.


--
-- Data for Name: JobCardTask; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobCardTask" (id, "jobCardId", "taskName", "taskDescription", status, "assignedWorkerId", "estimatedMinutes", "actualMinutes", notes, "sortOrder", "createdAt", "updatedAt") FROM stdin;
cmq8el17k007etk9wcawe83ir	cmq8ekqyd006otk9w8ly7z8oq	Initial Inspection	\N	DONE	\N	15	\N	\N	0	2026-06-10 18:29:36.225	2026-06-10 18:29:36.225
cmq8el1rw007gtk9wswh7dcqg	cmq8ekqyd006otk9w8ly7z8oq	Diagnose Issue	\N	DONE	\N	25	\N	\N	1	2026-06-10 18:29:36.956	2026-06-10 18:29:36.956
cmq8el2bz007itk9w1q93v6k6	cmq8ekqyd006otk9w8ly7z8oq	Replace Parts	\N	DONE	\N	35	\N	\N	2	2026-06-10 18:29:37.68	2026-06-10 18:29:37.68
cmq8el2yf007ktk9wx8ehzzor	cmq8ekqyd006otk9w8ly7z8oq	Test Ride	\N	DONE	\N	45	\N	\N	3	2026-06-10 18:29:38.488	2026-06-10 18:29:38.488
cmq8el3ij007mtk9wkubn1kpw	cmq8ekqyd006otk9w8ly7z8oq	Final QC	\N	DONE	\N	55	\N	\N	4	2026-06-10 18:29:39.211	2026-06-10 18:29:39.211
cmq8el42l007otk9wcqyely9b	cmq8eks30006qtk9w3k37670e	Initial Inspection	\N	DONE	\N	15	\N	\N	0	2026-06-10 18:29:39.933	2026-06-10 18:29:39.933
cmq8el4mr007qtk9whhddfkug	cmq8eks30006qtk9w3k37670e	Diagnose Issue	\N	DONE	\N	25	\N	\N	1	2026-06-10 18:29:40.66	2026-06-10 18:29:40.66
cmq8el56t007stk9w2np9n05h	cmq8eks30006qtk9w3k37670e	Replace Parts	\N	DONE	\N	35	\N	\N	2	2026-06-10 18:29:41.381	2026-06-10 18:29:41.381
cmq8el5qt007utk9w74087lkh	cmq8eks30006qtk9w3k37670e	Test Ride	\N	DONE	\N	45	\N	\N	3	2026-06-10 18:29:42.102	2026-06-10 18:29:42.102
cmq8el6az007wtk9wou1hjm27	cmq8eks30006qtk9w3k37670e	Final QC	\N	DONE	\N	55	\N	\N	4	2026-06-10 18:29:42.827	2026-06-10 18:29:42.827
cmq8el6vl007ytk9w85eoek2v	cmq8ekt7e006stk9w2kuaudmw	Initial Inspection	\N	DONE	\N	15	\N	\N	0	2026-06-10 18:29:43.569	2026-06-10 18:29:43.569
cmq8el7fn0080tk9w4wc1d1ho	cmq8ekt7e006stk9w2kuaudmw	Diagnose Issue	\N	DONE	\N	25	\N	\N	1	2026-06-10 18:29:44.291	2026-06-10 18:29:44.291
cmq8el7zo0082tk9wy22g68bb	cmq8ekt7e006stk9w2kuaudmw	Replace Parts	\N	DONE	\N	35	\N	\N	2	2026-06-10 18:29:45.013	2026-06-10 18:29:45.013
cmq8el8js0084tk9wcfmcgy4h	cmq8ekt7e006stk9w2kuaudmw	Test Ride	\N	IN_PROGRESS	\N	45	\N	\N	3	2026-06-10 18:29:45.737	2026-06-10 18:29:45.737
cmq8el93u0086tk9wfp965rgm	cmq8ekt7e006stk9w2kuaudmw	Final QC	\N	PENDING	\N	55	\N	\N	4	2026-06-10 18:29:46.458	2026-06-10 18:29:46.458
cmq8el9nv0088tk9w5ra90crg	cmq8ekubt006utk9w182c6uoa	Initial Inspection	\N	PENDING	\N	15	\N	\N	0	2026-06-10 18:29:47.179	2026-06-10 18:29:47.179
cmq8elaby008atk9wjm8xpd2i	cmq8ekubt006utk9w182c6uoa	Diagnose Issue	\N	PENDING	\N	25	\N	\N	1	2026-06-10 18:29:47.9	2026-06-10 18:29:47.9
cmq8elaw5008ctk9wzcns06rv	cmq8ekubt006utk9w182c6uoa	Replace Parts	\N	PENDING	\N	35	\N	\N	2	2026-06-10 18:29:48.773	2026-06-10 18:29:48.773
cmq8elbg8008etk9w0swsjm6t	cmq8ekubt006utk9w182c6uoa	Test Ride	\N	PENDING	\N	45	\N	\N	3	2026-06-10 18:29:49.496	2026-06-10 18:29:49.496
cmq8elc0c008gtk9whsn0cwdv	cmq8ekubt006utk9w182c6uoa	Final QC	\N	PENDING	\N	55	\N	\N	4	2026-06-10 18:29:50.221	2026-06-10 18:29:50.221
cmq8elckh008itk9ww6aah9eq	cmq8ekvhp006wtk9w117gjwjt	Initial Inspection	\N	PENDING	\N	15	\N	\N	0	2026-06-10 18:29:50.945	2026-06-10 18:29:50.945
cmq8eld4h008ktk9wdbgsno9t	cmq8ekvhp006wtk9w117gjwjt	Diagnose Issue	\N	PENDING	\N	25	\N	\N	1	2026-06-10 18:29:51.665	2026-06-10 18:29:51.665
cmq8eldoi008mtk9wxly1f9i6	cmq8ekvhp006wtk9w117gjwjt	Replace Parts	\N	PENDING	\N	35	\N	\N	2	2026-06-10 18:29:52.386	2026-06-10 18:29:52.386
cmq8ele90008otk9wumwculp2	cmq8ekvhp006wtk9w117gjwjt	Test Ride	\N	PENDING	\N	45	\N	\N	3	2026-06-10 18:29:53.124	2026-06-10 18:29:53.124
cmq8elesy008qtk9wg91or516	cmq8ekvhp006wtk9w117gjwjt	Final QC	\N	PENDING	\N	55	\N	\N	4	2026-06-10 18:29:53.842	2026-06-10 18:29:53.842
cmq93no5b0003pdph4vrgphe4	cmq8zs5qt0001ogmd2g7onc6s	CHAIN CLEAN	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 06:11:29.664	2026-06-11 06:11:29.664
cmq93nv9x0009pdphfw0z5wba	cmq8zs5qt0001ogmd2g7onc6s	FOAM WASH	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 06:11:38.881	2026-06-11 06:11:38.881
cmq94s17n0003cw11jb7rit8e	cmq94q7600008qplbsmhf4nq9	CASTROL 10W30	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 06:42:52.836	2026-06-11 06:42:52.836
cmq94s79v00038xw00ex76ium	cmq94q7600008qplbsmhf4nq9	General Service	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 06:43:00.691	2026-06-11 06:43:00.691
cmq958nf8000gcw11hyhrvb5c	cmq9345tu000kq3jpytm93djn	FOAM WASH	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 06:55:48.103	2026-06-11 06:55:48.103
cmq983rax00038ev6eu508ja7	cmq8z0yj4000aei5ir1tgdsfe	Labour charges 	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 08:15:58.688	2026-06-11 08:15:58.688
cmq984f6x0003galztmqn2s5z	cmq8z0yj4000aei5ir1tgdsfe	Castrol 20w40	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 08:16:29.648	2026-06-11 08:16:29.648
cmq9859dt00098ev6yvss6e3n	cmq8z0yj4000aei5ir1tgdsfe	Activ Castrol 20w40	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 08:17:08.778	2026-06-11 08:17:08.778
cmq9865nk000h8ev6xk5xmzoq	cmq8z0yj4000aei5ir1tgdsfe	Activ Castrol 20w40 	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 08:17:50.598	2026-06-11 08:17:50.598
cmq98pd6l0003uif5q8vgerdz	cmq95baj2000l8xw07dglk68b	AMC — GOLD (350cc+)	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 08:32:46.846	2026-06-11 08:32:46.846
cmq98pr0q000buif5ulvjbvsx	cmq95baj2000l8xw07dglk68b	AMC — GOLD (350cc+)	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 08:33:04.754	2026-06-11 08:33:04.754
cmq98qb5r000juif55nzk4bhr	cmq95baj2000l8xw07dglk68b	AMC — GOLD (350cc+)	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 08:33:30.88	2026-06-11 08:33:30.88
cmq98t0wp000puif5mzhiveag	cmq916uvk000ow352jjiacaui	washing charge	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 08:35:37.533	2026-06-11 08:35:37.533
cmq98tl590011uif5tkm4hjvw	cmq916uvk000ow352jjiacaui	foam wash 	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 08:36:03.79	2026-06-11 08:36:03.79
cmq9970li0005e1hk9ypj3m8c	cmq95baj2000l8xw07dglk68b	AMC — GOLD (350cc+)	\N	COMPLETED	\N	\N	\N	\N	0	2026-06-11 08:46:30.33	2026-06-11 08:46:30.33
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Notification" (id, channel, "eventType", "templateKey", "recipientPhone", "recipientEmail", "payloadJson", "sendStatus", "providerName", "providerMessageId", "errorMessage", "retryCount", "scheduledFor", "sentAt", "deliveredAt", "relatedEntityType", "relatedEntityId", "createdByAdminId", "createdAt") FROM stdin;
\.


--
-- Data for Name: NotificationTemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."NotificationTemplate" (id, channel, "eventType", "templateKey", subject, "messageBody", "variableSchemaJson", "isActive", "createdAt", "updatedAt") FROM stdin;
cmq8ekbqb005ftk9w5guejdud	WHATSAPP	appointment.confirmed	appt_confirmed_wa	\N	Hi {{customerName}}, your appointment on {{date}} at {{time}} is confirmed. Ref: {{referenceId}}	\N	t	2026-06-10 18:29:03.203	2026-06-10 18:29:03.203
cmq8ekcah005gtk9woaqmigfg	EMAIL	appointment.confirmed	appt_confirmed_email	Appointment Confirmed	Dear {{customerName}}, your appointment is confirmed for {{date}}.	\N	t	2026-06-10 18:29:03.929	2026-06-10 18:29:03.929
cmq8ekcuk005htk9wvcj5pwkb	WHATSAPP	jobcard.ready	jc_ready_wa	\N	Hi {{customerName}}, your {{vehicleReg}} is ready for pickup! Job Card: {{jobCardNumber}}	\N	t	2026-06-10 18:29:04.653	2026-06-10 18:29:04.653
cmq8ekdep005itk9w6pwn1mxk	EMAIL	invoice.created	invoice_email	Invoice {{invoiceNumber}}	Dear {{customerName}}, your invoice {{invoiceNumber}} for ₹{{amount}} is ready.	\N	t	2026-06-10 18:29:05.377	2026-06-10 18:29:05.377
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Payment" (id, "invoiceId", amount, "paymentMode", "paymentDate", "referenceNumber", notes, "receivedByAdminId", "createdAt") FROM stdin;
cmq8elong009mtk9w745kbjov	cmq8ellq6009ctk9wms0m2olr	1239.00	UPI	2026-06-03 18:29:10.441	UPI-REF-98765	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:30:06.605
cmq8elp7n009otk9w3haq0rh1	cmq8elnnb009htk9wdfl8o5cw	796.50	CASH	2026-06-05 18:29:10.441	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:30:07.332
cmq93o1870002984m7o19byqd	cmq8zs5rz0002ogmd9zwxup9e	74.00	UPI	2026-06-10 18:30:00	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 06:11:46.616
cmq94y9dp000acw11je17l480	cmq94q77b0009qplbs2jqz4au	750.00	CASH	2026-06-10 18:30:00	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 06:47:43.357
cmq958s5t000a8xw062h5rbki	cmq9345uu000lq3jpvlx0szcg	49.00	UPI	2026-06-10 18:30:00	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 06:55:54.258
cmq98tq1k0004nxsqasobvisp	cmq916ux6000pw3520720u1ao	49.00	UPI	2026-06-10 18:30:00	\N	\N	cmq8eh4ei0006tk9wa9s35hy4	2026-06-11 08:36:10.136
\.


--
-- Data for Name: Permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Permission" (id, key, module, name, description, "createdAt", "updatedAt") FROM stdin;
cmq8ehcle000jtk9w1ay65txc	CUSTOMERS_VIEW	CUSTOMERS	CUSTOMERS VIEW	\N	2026-06-10 18:26:44.354	2026-06-10 18:26:44.354
cmq8ehelm000mtk9wux49cwwj	CUSTOMERS_EDIT	CUSTOMERS	CUSTOMERS EDIT	\N	2026-06-10 18:26:46.955	2026-06-10 18:26:46.955
cmq8ehgn3000ptk9wsdoramgg	VEHICLES_VIEW	VEHICLES	VEHICLES VIEW	\N	2026-06-10 18:26:49.599	2026-06-10 18:26:49.599
cmq8ehin1000stk9w24zepcdg	VEHICLES_EDIT	VEHICLES	VEHICLES EDIT	\N	2026-06-10 18:26:52.19	2026-06-10 18:26:52.19
cmq8ehkne000vtk9wora2156b	WORKERS_MANAGE	WORKERS	WORKERS MANAGE	\N	2026-06-10 18:26:54.795	2026-06-10 18:26:54.795
cmq8ehmrg000ytk9wxcb0cm7x	APPOINTMENTS_VIEW	APPOINTMENTS	APPOINTMENTS VIEW	\N	2026-06-10 18:26:57.387	2026-06-10 18:26:57.387
cmq8ehot50011tk9wbgpk9oht	APPOINTMENTS_MANAGE	APPOINTMENTS	APPOINTMENTS MANAGE	\N	2026-06-10 18:27:00.185	2026-06-10 18:27:00.185
cmq8ehqt50014tk9wi0hr5vmr	JOB_CARDS_VIEW_OWN	JOB	JOB CARDS VIEW OWN	\N	2026-06-10 18:27:02.778	2026-06-10 18:27:02.778
cmq8ehstg0017tk9wo4wt6oow	JOB_CARDS_CREATE	JOB	JOB CARDS CREATE	\N	2026-06-10 18:27:05.381	2026-06-10 18:27:05.381
cmq8ehutk001atk9wut73whd2	JOB_CARDS_UPDATE_STATUS	JOB	JOB CARDS UPDATE STATUS	\N	2026-06-10 18:27:07.976	2026-06-10 18:27:07.976
cmq8ehwu2001dtk9wth513gls	INVENTORY_VIEW	INVENTORY	INVENTORY VIEW	\N	2026-06-10 18:27:10.587	2026-06-10 18:27:10.587
cmq8ehyyg001gtk9woe3o20ie	INVENTORY_EDIT	INVENTORY	INVENTORY EDIT	\N	2026-06-10 18:27:13.193	2026-06-10 18:27:13.193
cmq8ei0yy001jtk9w60w46cst	INVOICES_VIEW	INVOICES	INVOICES VIEW	\N	2026-06-10 18:27:15.947	2026-06-10 18:27:15.947
cmq8ei2za001mtk9wkmmwxsql	INVOICES_CREATE	INVOICES	INVOICES CREATE	\N	2026-06-10 18:27:18.551	2026-06-10 18:27:18.551
cmq8ei501001ptk9w6mr1dh0u	PAYMENTS_RECORD	PAYMENTS	PAYMENTS RECORD	\N	2026-06-10 18:27:21.169	2026-06-10 18:27:21.169
cmq8ei705001stk9wthz4gjal	EXPENSES_VIEW	EXPENSES	EXPENSES VIEW	\N	2026-06-10 18:27:23.765	2026-06-10 18:27:23.765
cmq8ei90n001vtk9w0593hbi8	EXPENSES_MANAGE	EXPENSES	EXPENSES MANAGE	\N	2026-06-10 18:27:26.375	2026-06-10 18:27:26.375
cmq8eib4w001ytk9w2znvd3sl	REPORTS_VIEW	REPORTS	REPORTS VIEW	\N	2026-06-10 18:27:28.977	2026-06-10 18:27:28.977
cmq8eid5h0021tk9w1dy991f1	SETTINGS_MANAGE	SETTINGS	SETTINGS MANAGE	\N	2026-06-10 18:27:31.734	2026-06-10 18:27:31.734
cmq8eif640024tk9wzyw3xj2l	NOTIFICATIONS_MANAGE	NOTIFICATIONS	NOTIFICATIONS MANAGE	\N	2026-06-10 18:27:34.349	2026-06-10 18:27:34.349
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Role" (id, key, name, description, "createdAt", "updatedAt") FROM stdin;
cmq8egycn0000tk9wa176ju1d	MECHANIC	Mechanic	Workshop mechanic	2026-06-10 18:26:25.895	2026-06-10 18:26:25.895
cmq8egzd30001tk9wn15m8rie	RECEPTIONIST	Receptionist	Front desk	2026-06-10 18:26:25.895	2026-06-10 18:26:25.895
cmq8eh0d60002tk9w9db4h81q	SUPER_ADMIN	Super Admin	Full access	2026-06-10 18:26:25.895	2026-06-10 18:26:25.895
cmq8eh1dd0003tk9w6643ppoh	MANAGER	Manager	Shop manager	2026-06-10 18:26:25.895	2026-06-10 18:26:25.895
\.


--
-- Data for Name: RolePermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RolePermission" (id, "roleId", "permissionId") FROM stdin;
cmq8ehdll000ltk9wxexzj05p	cmq8eh0d60002tk9w9db4h81q	cmq8ehcle000jtk9w1ay65txc
cmq8ehfmv000otk9wf48ogugf	cmq8eh0d60002tk9w9db4h81q	cmq8ehelm000mtk9wux49cwwj
cmq8ehhn2000rtk9wb0at81xz	cmq8eh0d60002tk9w9db4h81q	cmq8ehgn3000ptk9wsdoramgg
cmq8ehjn7000utk9w7w9k584a	cmq8eh0d60002tk9w9db4h81q	cmq8ehin1000stk9w24zepcdg
cmq8ehlnd000xtk9w1dfs5zkl	cmq8eh0d60002tk9w9db4h81q	cmq8ehkne000vtk9wora2156b
cmq8ehnrv0010tk9wwwc0yrqd	cmq8eh0d60002tk9w9db4h81q	cmq8ehmrg000ytk9wxcb0cm7x
cmq8ehpt40013tk9whgr26p09	cmq8eh0d60002tk9w9db4h81q	cmq8ehot50011tk9wbgpk9oht
cmq8ehrtj0016tk9w9j1broks	cmq8eh0d60002tk9w9db4h81q	cmq8ehqt50014tk9wi0hr5vmr
cmq8ehttj0019tk9wz7kup5dw	cmq8eh0d60002tk9w9db4h81q	cmq8ehstg0017tk9wo4wt6oow
cmq8ehvty001ctk9w8avs36o8	cmq8eh0d60002tk9w9db4h81q	cmq8ehutk001atk9wut73whd2
cmq8ehxu4001ftk9w1wobbswc	cmq8eh0d60002tk9w9db4h81q	cmq8ehwu2001dtk9wth513gls
cmq8ehzyw001itk9wbq69jw4j	cmq8eh0d60002tk9w9db4h81q	cmq8ehyyg001gtk9woe3o20ie
cmq8ei1z5001ltk9ww1hglzno	cmq8eh0d60002tk9w9db4h81q	cmq8ei0yy001jtk9w60w46cst
cmq8ei400001otk9wg0nerc9z	cmq8eh0d60002tk9w9db4h81q	cmq8ei2za001mtk9wkmmwxsql
cmq8ei604001rtk9wy8lz9rg4	cmq8eh0d60002tk9w9db4h81q	cmq8ei501001ptk9w6mr1dh0u
cmq8ei80n001utk9w1g062m6l	cmq8eh0d60002tk9w9db4h81q	cmq8ei705001stk9wthz4gjal
cmq8eia0l001xtk9wpfa4blmm	cmq8eh0d60002tk9w9db4h81q	cmq8ei90n001vtk9w0593hbi8
cmq8eic4x0020tk9w7hesmll7	cmq8eh0d60002tk9w9db4h81q	cmq8eib4w001ytk9w2znvd3sl
cmq8eie5u0023tk9wa52cmkix	cmq8eh0d60002tk9w9db4h81q	cmq8eid5h0021tk9w1dy991f1
cmq8eig660026tk9wf5rbot7l	cmq8eh0d60002tk9w9db4h81q	cmq8eif640024tk9wzyw3xj2l
\.


--
-- Data for Name: ServiceRequest; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ServiceRequest" (id, "referenceId", "customerId", "vehicleId", "serviceCategory", "issueDescription", "preferredDate", "preferredSlotLabel", urgency, "pickupDropRequired", notes, status, source, "closedAt", "createdAt", "updatedAt") FROM stdin;
cmq8ekhbe005qtk9w1o36z5lu	SR-2026-0001	cmq8eih670027tk9wj6jp8eaq	cmq8eimv0002itk9wesbpxfyv	Engine Repair	Engine making knocking sound at high RPM	\N	\N	\N	f	\N	CONVERTED_TO_JOB	SEED	\N	2026-05-31 18:29:10.441	2026-06-10 18:29:10.442
cmq8ekhvm005stk9wnbhazp59	SR-2026-0002	cmq8eihqb0028tk9w0gpzddyb	cmq8einf7002ktk9wwp4zuo1m	General Service	Regular 5000km service due, oil change needed	\N	\N	\N	f	\N	CONVERTED_TO_JOB	SEED	\N	2026-06-02 18:29:10.441	2026-06-10 18:29:11.17
cmq8ekifn005utk9wr34hxr5q	SR-2026-0003	cmq8eiiah0029tk9wuc979hbk	cmq8einzb002mtk9w5hc9iaq4	Brake & Clutch	Front brake not gripping properly, squeaking noise	\N	\N	\N	f	\N	CONVERTED_TO_JOB	SEED	\N	2026-06-04 18:29:10.441	2026-06-10 18:29:11.891
cmq8ekizr005wtk9wizn7g537	SR-2026-0004	cmq8eiiup002atk9wzpxd6gep	cmq8eiojm002otk9wdkyi20mn	Electrical & Wiring	Headlight flickering, battery draining overnight	\N	\N	\N	f	\N	CONVERTED_TO_JOB	SEED	\N	2026-06-05 18:29:10.441	2026-06-10 18:29:12.615
cmq8ekjjv005ytk9wy0yblsr6	SR-2026-0005	cmq8eijet002btk9wwe3limxe	cmq8eip3o002qtk9w7se62f98	Chain & Sprocket	Chain loose and making noise, sprocket teeth worn	\N	\N	\N	f	\N	CONVERTED_TO_JOB	SEED	\N	2026-06-06 18:29:10.441	2026-06-10 18:29:13.34
cmq8ekk3w0060tk9w3otdzaiq	SR-2026-0006	cmq8eijys002ctk9w3hdj0k4k	cmq8eipnp002stk9wic4kau8j	General Service	Bike vibrating at 60kmph, needs full checkup	\N	\N	\N	f	\N	APPOINTMENT_PENDING	SEED	\N	2026-06-07 18:29:10.441	2026-06-10 18:29:14.061
cmq8ekko00062tk9wdi9x42lx	SR-2026-0007	cmq8eikis002dtk9wda0pb6x4	cmq8eiq7r002utk9wm2cwfbr1	Tyre & Wheel Alignment	Front tyre worn out, needs replacement	\N	\N	\N	f	\N	APPOINTMENT_CONFIRMED	SEED	\N	2026-06-08 18:29:10.441	2026-06-10 18:29:14.785
cmq8ekl8c0064tk9wj0vp58j4	SR-2026-0008	cmq8eil2t002etk9w41q12clc	cmq8eiqrt002wtk9wwl4dbafq	Engine Repair	Clutch slipping on inclines, hard to shift gears	\N	\N	\N	f	\N	SUBMITTED	SEED	\N	2026-06-09 18:29:10.441	2026-06-10 18:29:15.516
cmq8eklsf0066tk9wjttk1d4u	SR-2026-0009	cmq8eilmx002ftk9w7fuqiqc1	cmq8eirbx002ytk9w6dd0nzt8	Body & Paint	Scratches on tank and side panel from minor fall	\N	\N	\N	f	\N	SUBMITTED	SEED	\N	2026-06-10 18:29:10.441	2026-06-10 18:29:16.24
cmq8ekmgg0068tk9wtru3a9s9	SR-2026-0010	cmq8eim6z002gtk9wm1yn00a2	cmq8eirvx0030tk9wvczo33g6	Diagnostics	Check engine light on, bike stalling randomly	\N	\N	\N	f	\N	UNDER_REVIEW	SEED	\N	2026-06-10 18:29:10.441	2026-06-10 18:29:16.961
\.


--
-- Data for Name: Setting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Setting" (id, key, value, "createdAt", "updatedAt") FROM stdin;
cmq8ekdyr005jtk9wyzwonfwl	business.name	"GearUp Bike Servicing"	2026-06-10 18:29:06.099	2026-06-10 18:29:06.099
cmq8ekeix005ktk9w0vvpm0l6	business.phone	"9830099900"	2026-06-10 18:29:06.825	2026-06-10 18:29:06.825
cmq8ekf2x005ltk9wplsb91b4	business.address	"42 Gariahat Road, Kolkata 700029"	2026-06-10 18:29:07.545	2026-06-10 18:29:07.545
cmq8ekfn6005mtk9wcmaev3j0	business.gst	"19AABCU9603R1ZM"	2026-06-10 18:29:08.274	2026-06-10 18:29:08.274
cmq8ekg76005ntk9w4zn4m4vc	invoice.prefix	"INV"	2026-06-10 18:29:08.994	2026-06-10 18:29:08.994
cmq8ekgr9005otk9wseu0po2w	invoice.terms	"Payment due within 7 days. No warranty on used parts."	2026-06-10 18:29:09.717	2026-06-10 18:29:09.717
\.


--
-- Data for Name: StockMovement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."StockMovement" (id, "inventoryItemId", "movementType", quantity, "previousQuantity", "newQuantity", "relatedEntityType", "relatedEntityId", reason, "performedByAdminId", "createdAt") FROM stdin;
cmq8elqwb009utk9wcgb5af3o	cmq8ejh7y003rtk9wiwqig5qo	STOCK_IN	10.00	40.00	50.00	\N	\N	Initial stock from supplier	cmq8eh4ei0006tk9wa9s35hy4	2026-05-26 18:29:10.441
cmq8elrgg009wtk9wa0jvfq5j	cmq8ejh7y003rtk9wiwqig5qo	RESERVED	2.00	50.00	48.00	JobCard	cmq8ekqyd006otk9w8ly7z8oq	\N	\N	2026-06-02 18:29:10.441
cmq8els0l009ytk9whoxewzuj	cmq8ejic9003ttk9w7qphf54b	STOCK_IN	10.00	10.00	20.00	\N	\N	Initial stock from supplier	cmq8eh4ei0006tk9wa9s35hy4	2026-05-26 18:29:10.441
cmq8elskl00a0tk9wb6ysfozv	cmq8ejic9003ttk9w7qphf54b	RESERVED	2.00	20.00	18.00	JobCard	cmq8ekqyd006otk9w8ly7z8oq	\N	\N	2026-06-02 18:29:10.441
cmq8elt4o00a2tk9wgke9hkn7	cmq8ejjgc003vtk9wbgrnnl29	STOCK_IN	10.00	20.00	30.00	\N	\N	Initial stock from supplier	cmq8eh4ei0006tk9wa9s35hy4	2026-05-26 18:29:10.441
cmq8eltox00a4tk9w41py36d5	cmq8ejjgc003vtk9wbgrnnl29	RESERVED	2.00	30.00	28.00	JobCard	cmq8ekqyd006otk9w8ly7z8oq	\N	\N	2026-06-02 18:29:10.441
\.


--
-- Data for Name: Supplier; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Supplier" (id, "supplierName", phone, email, address, "contactPerson", notes) FROM stdin;
cmq8ejdvj003ltk9wutv1pn7j	Bengal Auto Parts	9830111111	\N	Burrabazar, Kolkata	Ashok Kumar	\N
cmq8ejefl003mtk9widwsf9n5	Eastern Lubricants	9830333333	\N	Mullick Bazaar, Kolkata	Sunil Jain	\N
cmq8ejezj003ntk9wdn9jtmn1	Howrah Bike Spares	9830222222	\N	Howrah Station Road	Ramesh Agarwal	\N
cmq8ejfjk003otk9wp70gz2na	Kolkata Tyre House	9830444444	\N	Sealdah, Kolkata	Manoj Gupta	\N
cmq8ejg3q003ptk9wvtgfel24	Royal Parts Distributor	9830555555	\N	Esplanade, Kolkata	Vikram Singh	\N
\.


--
-- Data for Name: Vehicle; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Vehicle" (id, "customerId", "vehicleType", "registrationNumber", brand, model, variant, "yearOfManufacture", "fuelType", transmission, color, vin, "chassisNumber", "engineNumber", "engineCC", "odometerReading", notes, "createdAt", "updatedAt") FROM stdin;
cmq8eipnp002stk9wic4kau8j	cmq8eijys002ctk9w3hdj0k4k	BIKE	WB-26-KL-2345	Yamaha	FZ-S V3	\N	\N	Petrol	\N	Yellow	\N	\N	\N	\N	6015	\N	2026-06-10 18:27:47.941	2026-06-10 18:27:47.941
cmq8eiq7r002utk9wm2cwfbr1	cmq8eikis002dtk9wda0pb6x4	BIKE	WB-01-MN-6789	Suzuki	Access 125	\N	\N	Petrol	\N	Silver	\N	\N	\N	\N	9170	\N	2026-06-10 18:27:48.663	2026-06-10 18:27:48.663
cmq8eiqrt002wtk9wwl4dbafq	cmq8eil2t002etk9w41q12clc	BIKE	WB-02-OP-0123	KTM	Duke 200	\N	\N	Petrol	\N	Orange	\N	\N	\N	\N	9852	\N	2026-06-10 18:27:49.385	2026-06-10 18:27:49.385
cmq8eirbx002ytk9w6dd0nzt8	cmq8eilmx002ftk9w7fuqiqc1	BIKE	WB-26-QR-4567	Honda	CB Shine	\N	\N	Petrol	\N	Black	\N	\N	\N	\N	28445	\N	2026-06-10 18:27:50.109	2026-06-10 18:27:50.109
cmq8eirvx0030tk9wvczo33g6	cmq8eim6z002gtk9wm1yn00a2	BIKE	WB-01-ST-8901	Royal Enfield	Meteor 350	\N	\N	Petrol	\N	Green	\N	\N	\N	\N	33735	\N	2026-06-10 18:27:50.829	2026-06-10 18:27:50.829
cmq8eimv0002itk9wesbpxfyv	cmq8eih670027tk9wj6jp8eaq	BIKE	WB-01-AB-1234	Royal Enfield	Classic 350	\N	\N	Petrol	\N	Black	\N	\N	\N	\N	32982	\N	2026-06-10 18:27:44.173	2026-06-10 18:29:23.674
cmq8einf7002ktk9wwp4zuo1m	cmq8eihqb0028tk9w0gpzddyb	BIKE	WB-02-CD-5678	Honda	Activa 6G	\N	\N	Petrol	\N	White	\N	\N	\N	\N	11899	\N	2026-06-10 18:27:45.044	2026-06-10 18:29:25.123
cmq8einzb002mtk9w5hc9iaq4	cmq8eiiah0029tk9wuc979hbk	BIKE	WB-26-EF-9012	Bajaj	Pulsar 150	\N	\N	Petrol	\N	Blue	\N	\N	\N	\N	14717	\N	2026-06-10 18:27:45.767	2026-06-10 18:29:26.577
cmq8eiojm002otk9wdkyi20mn	cmq8eiiup002atk9wzpxd6gep	BIKE	WB-01-GH-3456	TVS	Jupiter	\N	\N	Petrol	\N	Grey	\N	\N	\N	\N	16690	\N	2026-06-10 18:27:46.498	2026-06-10 18:29:28.085
cmq8eip3o002qtk9w7se62f98	cmq8eijet002btk9wwe3limxe	BIKE	WB-02-IJ-7890	Hero	Splendor Plus	\N	\N	Petrol	\N	Red	\N	\N	\N	\N	17915	\N	2026-06-10 18:27:47.22	2026-06-10 18:29:29.538
cmq8z0hq40006ei5ifaqsfpcr	cmq8yz8tu0002ei5io346nbz6	BIKE	WB-68-W-4828	tvs 	xl100	\N	\N	\N	\N	\N	\N	\N	\N	\N	5668	\N	2026-06-11 04:01:29.778	2026-06-11 04:01:51.593
cmq8zgx6t0004c0up8blgf3a3	cmq8zgfk10000c0uptfnpc77f	BIKE	WB-68-W-4341	Avengers 	B4	\N	\N	\N	\N	\N	\N	\N	\N	\N	9506	\N	2026-06-11 04:14:16.321	2026-06-11 04:14:50.282
cmq8zqd3m00044pnf93zcloss	cmq8zpxoa00004pnfqeua0fxf	BIKE	WB-67-H-6582	Honda 	Hornet	\N	\N	\N	\N	\N	\N	\N	\N	\N	9865	\N	2026-06-11 04:21:36.851	2026-06-11 04:23:00.655
cmq907hjc0004v0ipiiop2nqj	cmq906y050000v0ipb3zif22u	BIKE	WB-68-N-0885	Hero 	Hf deluxe 	\N	\N	\N	\N	\N	\N	\N	\N	\N	5299	\N	2026-06-11 04:34:55.742	2026-06-11 04:36:14.36
cmq90b5ad000gv0ip606qeqm6	cmq90aqgy000cv0ipx2o9ehnl	BIKE	WB-68-AM-1263	Honda	SP125	\N	\N	\N	\N	\N	\N	\N	\N	\N	14605	\N	2026-06-11 04:37:46.498	2026-06-11 04:40:07.868
cmq90qukt0004w352hl9rne4u	cmq90qcbi0000w352n3yauaux	BIKE	WB-68-AF-2813	Royal	Enfield 	\N	\N	\N	\N	\N	\N	\N	\N	\N	9686	\N	2026-06-11 04:49:59.097	2026-06-11 04:50:35.422
cmq916mf0000kw352sukhqh2a	cmq9164ef000gw352im1qlnev	BIKE	WB-68-AP-6411	Royal Enfield 	Classic 350	\N	\N	\N	\N	\N	\N	\N	\N	\N	68062	\N	2026-06-11 05:02:15.008	2026-06-11 05:02:26.03
cmq92ucij0004q3jp9rbw3nli	cmq92syu40000q3jpsrf3z87h	BIKE	WB-68-R-2377	Honda	Dream Neo 110	\N	\N	\N	\N	\N	\N	\N	\N	\N	43371	\N	2026-06-11 05:48:41.557	2026-06-11 05:52:07.784
cmq932ic7000gq3jprhxini79	cmq9321y4000cq3jpjjbuad34	BIKE	WB-68-AG-6605	Hero 	Glamour 	\N	\N	\N	\N	\N	\N	\N	\N	\N	57742	\N	2026-06-11 05:55:02.35	2026-06-11 05:56:19.476
cmq93wc0i000ipdphqz3sbeul	cmq93vtem000epdphfnndmaf5	BIKE	WB-68-W-9225	HORNET 	160	\N	\N	\N	\N	\N	\N	\N	\N	\N	5662	\N	2026-06-11 06:18:13.823	2026-06-11 06:18:47.971
cmq9407qc000updphadqqd9b2	cmq93zrzr000qpdph0uog4py3	BIKE	WB-68-AN-1061	R 	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	5656	\N	2026-06-11 06:21:14.904	2026-06-11 06:21:39.726
cmq94px7i0004qplberzhfail	cmq94p3920000qplb19fz53pl	BIKE	WB-68-Z-7041	HONDA	ACTIVA 	\N	\N	\N	\N	\N	\N	\N	\N	\N	8642	\N	2026-06-11 06:41:14.319	2026-06-11 06:41:27.265
cmq95awcf000h8xw0bjuy7tzj	cmq95ac2j000d8xw0nzx65tyh	BIKE	W-68-AQ-3433	CLASSIC	350	\N	\N	\N	\N	\N	\N	\N	\N	\N	5565	\N	2026-06-11 06:57:32.979	2026-06-11 06:57:51.394
\.


--
-- Data for Name: Worker; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Worker" (id, "workerCode", "fullName", "phoneNumber", email, designation, specialization, "employmentType", "joiningDate", "dailyCapacity", "shiftStart", "shiftEnd", status, "emergencyContactName", "emergencyContactPhone", address, notes, "monthlySalary", "createdAt", "updatedAt") FROM stdin;
cmq8eit080031tk9wn63ntqvk	WRK-001	Raju Mistri	9832011111	\N	Senior Mechanic	Engine	\N	\N	5	09:00	18:00	ACTIVE	\N	\N	\N	\N	\N	2026-06-10 18:27:52.28	2026-06-10 18:27:52.28
cmq8eiu4g0032tk9w44nuo2mf	WRK-002	Bablu Das	9832022222	\N	Mechanic	Electrical	\N	\N	5	09:00	18:00	ACTIVE	\N	\N	\N	\N	\N	2026-06-10 18:27:53.728	2026-06-10 18:27:53.728
cmq8eiv8m0033tk9wm7l9qe3g	WRK-003	Tapan Karmakar	9832033333	\N	Mechanic	Brake & Clutch	\N	\N	5	09:00	18:00	ACTIVE	\N	\N	\N	\N	\N	2026-06-10 18:27:55.174	2026-06-10 18:27:55.174
cmq8eiwd20034tk9wnrnt27ko	WRK-004	Sanjay Mitra	9832044444	\N	Junior Mechanic	General Service	\N	\N	5	10:00	19:00	ACTIVE	\N	\N	\N	\N	\N	2026-06-10 18:27:56.63	2026-06-10 18:27:56.63
cmq8eixh80035tk9wbifkfvns	WRK-005	Pintu Shaw	9832055555	\N	Helper	Body & Paint	\N	\N	5	09:00	18:00	ACTIVE	\N	\N	\N	\N	\N	2026-06-10 18:27:58.076	2026-06-10 18:27:58.076
cmq8eiypm0036tk9wae66zuzf	WRK-006	Manoj Thakur	9832066666	\N	Senior Mechanic	Chain & Sprocket	\N	\N	5	09:00	18:00	ACTIVE	\N	\N	\N	\N	\N	2026-06-10 18:27:59.531	2026-06-10 18:27:59.531
cmq8eizty0037tk9wb8yvv24c	WRK-007	Bikash Dey	9832077777	\N	Mechanic	Tyre & Wheel	\N	\N	5	10:00	19:00	ACTIVE	\N	\N	\N	\N	\N	2026-06-10 18:28:01.127	2026-06-10 18:28:01.127
cmq8ej0y00038tk9wbtd9k3b4	WRK-008	Gopal Mandal	9832088888	\N	Mechanic	Engine	\N	\N	5	09:00	18:00	ACTIVE	\N	\N	\N	\N	\N	2026-06-10 18:28:02.568	2026-06-10 18:28:02.568
cmq8ej2280039tk9wdx8ks2c1	WRK-009	Arun Pramanik	9832099999	\N	Junior Mechanic	Diagnostics	\N	\N	5	09:00	18:00	ACTIVE	\N	\N	\N	\N	\N	2026-06-10 18:28:04.016	2026-06-10 18:28:04.016
cmq8ej36f003atk9wucd5ypah	WRK-010	Dilip Naskar	9832000000	\N	Helper	General Service	\N	\N	5	10:00	19:00	ACTIVE	\N	\N	\N	\N	\N	2026-06-10 18:28:05.463	2026-06-10 18:28:05.463
\.


--
-- Data for Name: WorkerAssignment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."WorkerAssignment" (id, "jobCardId", "workerId", "assignmentRole", "assignedAt", "unassignedAt", notes) FROM stdin;
cmq8ekwlw006ytk9wd97v5asx	cmq8ekqyd006otk9w8ly7z8oq	cmq8eit080031tk9wn63ntqvk	Senior Mechanic	2026-06-10 18:29:30.26	\N	\N
cmq8ekx640070tk9wwjzp2gqu	cmq8ekqyd006otk9w8ly7z8oq	cmq8eiypm0036tk9wae66zuzf	Helper	2026-06-10 18:29:30.989	\N	\N
cmq8ekxq40072tk9wtbxitvq0	cmq8eks30006qtk9w3k37670e	cmq8eiu4g0032tk9w44nuo2mf	Mechanic	2026-06-10 18:29:31.709	\N	\N
cmq8ekye60074tk9wowv8sfpe	cmq8eks30006qtk9w3k37670e	cmq8eizty0037tk9wb8yvv24c	Helper	2026-06-10 18:29:32.431	\N	\N
cmq8ekyz50076tk9wfmdc24ns	cmq8ekt7e006stk9w2kuaudmw	cmq8eiv8m0033tk9wm7l9qe3g	Mechanic	2026-06-10 18:29:33.329	\N	\N
cmq8ekzj90078tk9wsrg6u79v	cmq8ekt7e006stk9w2kuaudmw	cmq8ej0y00038tk9wbtd9k3b4	Helper	2026-06-10 18:29:34.053	\N	\N
cmq8el03g007atk9w18670vzz	cmq8ekubt006utk9w182c6uoa	cmq8eiwd20034tk9wnrnt27ko	Junior Mechanic	2026-06-10 18:29:34.78	\N	\N
cmq8el0nh007ctk9w78saiqiv	cmq8ekvhp006wtk9w117gjwjt	cmq8eixh80035tk9wbifkfvns	Helper	2026-06-10 18:29:35.501	\N	\N
\.


--
-- Data for Name: WorkerLeave; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."WorkerLeave" (id, "workerId", "leaveType", "startDate", "endDate", "partialDay", "partialStartTime", "partialEndTime", status, reason, "approvedByAdminId", "createdAt", "updatedAt") FROM stdin;
cmq8elps3009qtk9wi3bhjzl8	cmq8eiwd20034tk9wnrnt27ko	CASUAL	2026-06-12 18:29:10.441	2026-06-13 18:29:10.441	f	\N	\N	APPROVED	Family function	cmq8eh4ei0006tk9wa9s35hy4	2026-06-10 18:30:08.068	2026-06-10 18:30:08.068
cmq8elqc9009stk9w47oxcmyf	cmq8ej0y00038tk9wbtd9k3b4	SICK	2026-06-15 18:29:10.441	2026-06-15 18:29:10.441	f	\N	\N	PENDING	Not feeling well	\N	2026-06-10 18:30:08.793	2026-06-10 18:30:08.793
\.


--
-- Name: ActivityLog ActivityLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ActivityLog"
    ADD CONSTRAINT "ActivityLog_pkey" PRIMARY KEY (id);


--
-- Name: AdminUserRole AdminUserRole_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AdminUserRole"
    ADD CONSTRAINT "AdminUserRole_pkey" PRIMARY KEY (id);


--
-- Name: AdminUser AdminUser_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AdminUser"
    ADD CONSTRAINT "AdminUser_pkey" PRIMARY KEY (id);


--
-- Name: AmcContract AmcContract_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AmcContract"
    ADD CONSTRAINT "AmcContract_pkey" PRIMARY KEY (id);


--
-- Name: AmcPlan AmcPlan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AmcPlan"
    ADD CONSTRAINT "AmcPlan_pkey" PRIMARY KEY (id);


--
-- Name: AmcServiceUsage AmcServiceUsage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AmcServiceUsage"
    ADD CONSTRAINT "AmcServiceUsage_pkey" PRIMARY KEY (id);


--
-- Name: AppointmentSlotRule AppointmentSlotRule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AppointmentSlotRule"
    ADD CONSTRAINT "AppointmentSlotRule_pkey" PRIMARY KEY (id);


--
-- Name: Appointment Appointment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_pkey" PRIMARY KEY (id);


--
-- Name: BlockedSlot BlockedSlot_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BlockedSlot"
    ADD CONSTRAINT "BlockedSlot_pkey" PRIMARY KEY (id);


--
-- Name: Customer Customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY (id);


--
-- Name: ExpenseCategory ExpenseCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ExpenseCategory"
    ADD CONSTRAINT "ExpenseCategory_pkey" PRIMARY KEY (id);


--
-- Name: Expense Expense_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Expense"
    ADD CONSTRAINT "Expense_pkey" PRIMARY KEY (id);


--
-- Name: Holiday Holiday_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Holiday"
    ADD CONSTRAINT "Holiday_pkey" PRIMARY KEY (id);


--
-- Name: InventoryCategory InventoryCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InventoryCategory"
    ADD CONSTRAINT "InventoryCategory_pkey" PRIMARY KEY (id);


--
-- Name: InventoryItem InventoryItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InventoryItem"
    ADD CONSTRAINT "InventoryItem_pkey" PRIMARY KEY (id);


--
-- Name: InvoiceLineItem InvoiceLineItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InvoiceLineItem"
    ADD CONSTRAINT "InvoiceLineItem_pkey" PRIMARY KEY (id);


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY (id);


--
-- Name: JobCardPart JobCardPart_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobCardPart"
    ADD CONSTRAINT "JobCardPart_pkey" PRIMARY KEY (id);


--
-- Name: JobCardTask JobCardTask_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobCardTask"
    ADD CONSTRAINT "JobCardTask_pkey" PRIMARY KEY (id);


--
-- Name: JobCard JobCard_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobCard"
    ADD CONSTRAINT "JobCard_pkey" PRIMARY KEY (id);


--
-- Name: NotificationTemplate NotificationTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NotificationTemplate"
    ADD CONSTRAINT "NotificationTemplate_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: Permission Permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Permission"
    ADD CONSTRAINT "Permission_pkey" PRIMARY KEY (id);


--
-- Name: RolePermission RolePermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_pkey" PRIMARY KEY (id);


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (id);


--
-- Name: ServiceRequest ServiceRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceRequest"
    ADD CONSTRAINT "ServiceRequest_pkey" PRIMARY KEY (id);


--
-- Name: Setting Setting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Setting"
    ADD CONSTRAINT "Setting_pkey" PRIMARY KEY (id);


--
-- Name: StockMovement StockMovement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_pkey" PRIMARY KEY (id);


--
-- Name: Supplier Supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Supplier"
    ADD CONSTRAINT "Supplier_pkey" PRIMARY KEY (id);


--
-- Name: Vehicle Vehicle_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vehicle"
    ADD CONSTRAINT "Vehicle_pkey" PRIMARY KEY (id);


--
-- Name: WorkerAssignment WorkerAssignment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkerAssignment"
    ADD CONSTRAINT "WorkerAssignment_pkey" PRIMARY KEY (id);


--
-- Name: WorkerLeave WorkerLeave_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkerLeave"
    ADD CONSTRAINT "WorkerLeave_pkey" PRIMARY KEY (id);


--
-- Name: Worker Worker_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Worker"
    ADD CONSTRAINT "Worker_pkey" PRIMARY KEY (id);


--
-- Name: ActivityLog_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ActivityLog_action_idx" ON public."ActivityLog" USING btree (action);


--
-- Name: ActivityLog_actorType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ActivityLog_actorType_idx" ON public."ActivityLog" USING btree ("actorType");


--
-- Name: ActivityLog_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ActivityLog_createdAt_idx" ON public."ActivityLog" USING btree ("createdAt");


--
-- Name: ActivityLog_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ActivityLog_entityType_entityId_idx" ON public."ActivityLog" USING btree ("entityType", "entityId");


--
-- Name: AdminUserRole_adminUserId_roleId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AdminUserRole_adminUserId_roleId_key" ON public."AdminUserRole" USING btree ("adminUserId", "roleId");


--
-- Name: AdminUser_adminUserId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AdminUser_adminUserId_key" ON public."AdminUser" USING btree ("adminUserId");


--
-- Name: AdminUser_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AdminUser_email_key" ON public."AdminUser" USING btree (email);


--
-- Name: AmcContract_amcPlanId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AmcContract_amcPlanId_idx" ON public."AmcContract" USING btree ("amcPlanId");


--
-- Name: AmcContract_contractNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AmcContract_contractNumber_key" ON public."AmcContract" USING btree ("contractNumber");


--
-- Name: AmcContract_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AmcContract_customerId_idx" ON public."AmcContract" USING btree ("customerId");


--
-- Name: AmcContract_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AmcContract_status_idx" ON public."AmcContract" USING btree (status);


--
-- Name: AmcContract_vehicleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AmcContract_vehicleId_idx" ON public."AmcContract" USING btree ("vehicleId");


--
-- Name: AmcServiceUsage_amcContractId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AmcServiceUsage_amcContractId_idx" ON public."AmcServiceUsage" USING btree ("amcContractId");


--
-- Name: AmcServiceUsage_amcContractId_jobCardId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AmcServiceUsage_amcContractId_jobCardId_key" ON public."AmcServiceUsage" USING btree ("amcContractId", "jobCardId");


--
-- Name: AmcServiceUsage_jobCardId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AmcServiceUsage_jobCardId_idx" ON public."AmcServiceUsage" USING btree ("jobCardId");


--
-- Name: Appointment_appointmentDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Appointment_appointmentDate_idx" ON public."Appointment" USING btree ("appointmentDate");


--
-- Name: Appointment_assignedWorkerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Appointment_assignedWorkerId_idx" ON public."Appointment" USING btree ("assignedWorkerId");


--
-- Name: Appointment_confirmedByAdminId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Appointment_confirmedByAdminId_idx" ON public."Appointment" USING btree ("confirmedByAdminId");


--
-- Name: Appointment_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Appointment_customerId_idx" ON public."Appointment" USING btree ("customerId");


--
-- Name: Appointment_referenceId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Appointment_referenceId_key" ON public."Appointment" USING btree ("referenceId");


--
-- Name: Appointment_serviceRequestId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Appointment_serviceRequestId_key" ON public."Appointment" USING btree ("serviceRequestId");


--
-- Name: Appointment_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Appointment_status_idx" ON public."Appointment" USING btree (status);


--
-- Name: Appointment_vehicleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Appointment_vehicleId_idx" ON public."Appointment" USING btree ("vehicleId");


--
-- Name: BlockedSlot_blockDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "BlockedSlot_blockDate_idx" ON public."BlockedSlot" USING btree ("blockDate");


--
-- Name: Customer_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Customer_email_idx" ON public."Customer" USING btree (email);


--
-- Name: ExpenseCategory_categoryName_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ExpenseCategory_categoryName_key" ON public."ExpenseCategory" USING btree ("categoryName");


--
-- Name: Expense_categoryId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Expense_categoryId_idx" ON public."Expense" USING btree ("categoryId");


--
-- Name: Expense_createdByAdminId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Expense_createdByAdminId_idx" ON public."Expense" USING btree ("createdByAdminId");


--
-- Name: Expense_expenseDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Expense_expenseDate_idx" ON public."Expense" USING btree ("expenseDate");


--
-- Name: Holiday_holidayDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Holiday_holidayDate_idx" ON public."Holiday" USING btree ("holidayDate");


--
-- Name: InventoryCategory_categoryName_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "InventoryCategory_categoryName_key" ON public."InventoryCategory" USING btree ("categoryName");


--
-- Name: InventoryItem_categoryId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "InventoryItem_categoryId_idx" ON public."InventoryItem" USING btree ("categoryId");


--
-- Name: InventoryItem_itemName_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "InventoryItem_itemName_idx" ON public."InventoryItem" USING btree ("itemName");


--
-- Name: InventoryItem_sku_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "InventoryItem_sku_key" ON public."InventoryItem" USING btree (sku);


--
-- Name: InventoryItem_supplierId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "InventoryItem_supplierId_idx" ON public."InventoryItem" USING btree ("supplierId");


--
-- Name: InvoiceLineItem_invoiceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "InvoiceLineItem_invoiceId_idx" ON public."InvoiceLineItem" USING btree ("invoiceId");


--
-- Name: Invoice_appointmentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Invoice_appointmentId_idx" ON public."Invoice" USING btree ("appointmentId");


--
-- Name: Invoice_createdByAdminId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Invoice_createdByAdminId_idx" ON public."Invoice" USING btree ("createdByAdminId");


--
-- Name: Invoice_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Invoice_customerId_idx" ON public."Invoice" USING btree ("customerId");


--
-- Name: Invoice_customerId_paymentStatus_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Invoice_customerId_paymentStatus_idx" ON public."Invoice" USING btree ("customerId", "paymentStatus");


--
-- Name: Invoice_invoiceDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Invoice_invoiceDate_idx" ON public."Invoice" USING btree ("invoiceDate");


--
-- Name: Invoice_invoiceDate_paymentStatus_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Invoice_invoiceDate_paymentStatus_idx" ON public."Invoice" USING btree ("invoiceDate", "paymentStatus");


--
-- Name: Invoice_invoiceNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Invoice_invoiceNumber_key" ON public."Invoice" USING btree ("invoiceNumber");


--
-- Name: Invoice_jobCardId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Invoice_jobCardId_idx" ON public."Invoice" USING btree ("jobCardId");


--
-- Name: Invoice_paymentStatus_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Invoice_paymentStatus_idx" ON public."Invoice" USING btree ("paymentStatus");


--
-- Name: Invoice_vehicleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Invoice_vehicleId_idx" ON public."Invoice" USING btree ("vehicleId");


--
-- Name: JobCardPart_inventoryItemId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "JobCardPart_inventoryItemId_idx" ON public."JobCardPart" USING btree ("inventoryItemId");


--
-- Name: JobCardPart_jobCardId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "JobCardPart_jobCardId_idx" ON public."JobCardPart" USING btree ("jobCardId");


--
-- Name: JobCardPart_jobCardId_inventoryItemId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "JobCardPart_jobCardId_inventoryItemId_key" ON public."JobCardPart" USING btree ("jobCardId", "inventoryItemId");


--
-- Name: JobCardTask_assignedWorkerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "JobCardTask_assignedWorkerId_idx" ON public."JobCardTask" USING btree ("assignedWorkerId");


--
-- Name: JobCardTask_jobCardId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "JobCardTask_jobCardId_idx" ON public."JobCardTask" USING btree ("jobCardId");


--
-- Name: JobCard_appointmentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "JobCard_appointmentId_idx" ON public."JobCard" USING btree ("appointmentId");


--
-- Name: JobCard_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "JobCard_customerId_idx" ON public."JobCard" USING btree ("customerId");


--
-- Name: JobCard_customerId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "JobCard_customerId_status_idx" ON public."JobCard" USING btree ("customerId", status);


--
-- Name: JobCard_estimateToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "JobCard_estimateToken_key" ON public."JobCard" USING btree ("estimateToken");


--
-- Name: JobCard_jobCardNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "JobCard_jobCardNumber_key" ON public."JobCard" USING btree ("jobCardNumber");


--
-- Name: JobCard_serviceRequestId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "JobCard_serviceRequestId_idx" ON public."JobCard" USING btree ("serviceRequestId");


--
-- Name: JobCard_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "JobCard_status_idx" ON public."JobCard" USING btree (status);


--
-- Name: JobCard_vehicleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "JobCard_vehicleId_idx" ON public."JobCard" USING btree ("vehicleId");


--
-- Name: JobCard_vehicleId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "JobCard_vehicleId_status_idx" ON public."JobCard" USING btree ("vehicleId", status);


--
-- Name: NotificationTemplate_templateKey_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "NotificationTemplate_templateKey_key" ON public."NotificationTemplate" USING btree ("templateKey");


--
-- Name: Notification_eventType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Notification_eventType_idx" ON public."Notification" USING btree ("eventType");


--
-- Name: Notification_scheduledFor_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Notification_scheduledFor_idx" ON public."Notification" USING btree ("scheduledFor");


--
-- Name: Notification_sendStatus_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Notification_sendStatus_idx" ON public."Notification" USING btree ("sendStatus");


--
-- Name: Payment_invoiceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Payment_invoiceId_idx" ON public."Payment" USING btree ("invoiceId");


--
-- Name: Payment_paymentDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Payment_paymentDate_idx" ON public."Payment" USING btree ("paymentDate");


--
-- Name: Payment_receivedByAdminId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Payment_receivedByAdminId_idx" ON public."Payment" USING btree ("receivedByAdminId");


--
-- Name: Permission_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Permission_key_key" ON public."Permission" USING btree (key);


--
-- Name: RolePermission_roleId_permissionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "RolePermission_roleId_permissionId_key" ON public."RolePermission" USING btree ("roleId", "permissionId");


--
-- Name: Role_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Role_key_key" ON public."Role" USING btree (key);


--
-- Name: ServiceRequest_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ServiceRequest_customerId_idx" ON public."ServiceRequest" USING btree ("customerId");


--
-- Name: ServiceRequest_referenceId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ServiceRequest_referenceId_key" ON public."ServiceRequest" USING btree ("referenceId");


--
-- Name: ServiceRequest_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ServiceRequest_status_idx" ON public."ServiceRequest" USING btree (status);


--
-- Name: ServiceRequest_vehicleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ServiceRequest_vehicleId_idx" ON public."ServiceRequest" USING btree ("vehicleId");


--
-- Name: Setting_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Setting_key_key" ON public."Setting" USING btree (key);


--
-- Name: StockMovement_inventoryItemId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "StockMovement_inventoryItemId_idx" ON public."StockMovement" USING btree ("inventoryItemId");


--
-- Name: StockMovement_movementType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "StockMovement_movementType_idx" ON public."StockMovement" USING btree ("movementType");


--
-- Name: Vehicle_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Vehicle_customerId_idx" ON public."Vehicle" USING btree ("customerId");


--
-- Name: WorkerAssignment_jobCardId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "WorkerAssignment_jobCardId_idx" ON public."WorkerAssignment" USING btree ("jobCardId");


--
-- Name: WorkerAssignment_jobCardId_workerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "WorkerAssignment_jobCardId_workerId_key" ON public."WorkerAssignment" USING btree ("jobCardId", "workerId");


--
-- Name: WorkerAssignment_workerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "WorkerAssignment_workerId_idx" ON public."WorkerAssignment" USING btree ("workerId");


--
-- Name: WorkerLeave_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "WorkerLeave_status_idx" ON public."WorkerLeave" USING btree (status);


--
-- Name: WorkerLeave_workerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "WorkerLeave_workerId_idx" ON public."WorkerLeave" USING btree ("workerId");


--
-- Name: Worker_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Worker_status_idx" ON public."Worker" USING btree (status);


--
-- Name: Worker_workerCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Worker_workerCode_key" ON public."Worker" USING btree ("workerCode");


--
-- Name: AdminUserRole AdminUserRole_adminUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AdminUserRole"
    ADD CONSTRAINT "AdminUserRole_adminUserId_fkey" FOREIGN KEY ("adminUserId") REFERENCES public."AdminUser"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AdminUserRole AdminUserRole_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AdminUserRole"
    ADD CONSTRAINT "AdminUserRole_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AmcContract AmcContract_amcPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AmcContract"
    ADD CONSTRAINT "AmcContract_amcPlanId_fkey" FOREIGN KEY ("amcPlanId") REFERENCES public."AmcPlan"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AmcContract AmcContract_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AmcContract"
    ADD CONSTRAINT "AmcContract_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AmcContract AmcContract_vehicleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AmcContract"
    ADD CONSTRAINT "AmcContract_vehicleId_fkey" FOREIGN KEY ("vehicleId") REFERENCES public."Vehicle"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AmcServiceUsage AmcServiceUsage_amcContractId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AmcServiceUsage"
    ADD CONSTRAINT "AmcServiceUsage_amcContractId_fkey" FOREIGN KEY ("amcContractId") REFERENCES public."AmcContract"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AmcServiceUsage AmcServiceUsage_jobCardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AmcServiceUsage"
    ADD CONSTRAINT "AmcServiceUsage_jobCardId_fkey" FOREIGN KEY ("jobCardId") REFERENCES public."JobCard"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Appointment Appointment_assignedWorkerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_assignedWorkerId_fkey" FOREIGN KEY ("assignedWorkerId") REFERENCES public."Worker"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Appointment Appointment_confirmedByAdminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_confirmedByAdminId_fkey" FOREIGN KEY ("confirmedByAdminId") REFERENCES public."AdminUser"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Appointment Appointment_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Appointment Appointment_serviceRequestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_serviceRequestId_fkey" FOREIGN KEY ("serviceRequestId") REFERENCES public."ServiceRequest"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Appointment Appointment_vehicleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_vehicleId_fkey" FOREIGN KEY ("vehicleId") REFERENCES public."Vehicle"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Expense Expense_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Expense"
    ADD CONSTRAINT "Expense_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."ExpenseCategory"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Expense Expense_createdByAdminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Expense"
    ADD CONSTRAINT "Expense_createdByAdminId_fkey" FOREIGN KEY ("createdByAdminId") REFERENCES public."AdminUser"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: InventoryItem InventoryItem_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InventoryItem"
    ADD CONSTRAINT "InventoryItem_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."InventoryCategory"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: InventoryItem InventoryItem_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InventoryItem"
    ADD CONSTRAINT "InventoryItem_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public."Supplier"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: InvoiceLineItem InvoiceLineItem_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InvoiceLineItem"
    ADD CONSTRAINT "InvoiceLineItem_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invoice Invoice_createdByAdminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_createdByAdminId_fkey" FOREIGN KEY ("createdByAdminId") REFERENCES public."AdminUser"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Invoice Invoice_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Invoice Invoice_jobCardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_jobCardId_fkey" FOREIGN KEY ("jobCardId") REFERENCES public."JobCard"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Invoice Invoice_vehicleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_vehicleId_fkey" FOREIGN KEY ("vehicleId") REFERENCES public."Vehicle"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobCardPart JobCardPart_inventoryItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobCardPart"
    ADD CONSTRAINT "JobCardPart_inventoryItemId_fkey" FOREIGN KEY ("inventoryItemId") REFERENCES public."InventoryItem"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobCardPart JobCardPart_jobCardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobCardPart"
    ADD CONSTRAINT "JobCardPart_jobCardId_fkey" FOREIGN KEY ("jobCardId") REFERENCES public."JobCard"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: JobCardTask JobCardTask_assignedWorkerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobCardTask"
    ADD CONSTRAINT "JobCardTask_assignedWorkerId_fkey" FOREIGN KEY ("assignedWorkerId") REFERENCES public."Worker"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: JobCardTask JobCardTask_jobCardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobCardTask"
    ADD CONSTRAINT "JobCardTask_jobCardId_fkey" FOREIGN KEY ("jobCardId") REFERENCES public."JobCard"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: JobCard JobCard_appointmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobCard"
    ADD CONSTRAINT "JobCard_appointmentId_fkey" FOREIGN KEY ("appointmentId") REFERENCES public."Appointment"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: JobCard JobCard_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobCard"
    ADD CONSTRAINT "JobCard_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobCard JobCard_serviceRequestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobCard"
    ADD CONSTRAINT "JobCard_serviceRequestId_fkey" FOREIGN KEY ("serviceRequestId") REFERENCES public."ServiceRequest"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: JobCard JobCard_vehicleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobCard"
    ADD CONSTRAINT "JobCard_vehicleId_fkey" FOREIGN KEY ("vehicleId") REFERENCES public."Vehicle"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Notification Notification_createdByAdminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_createdByAdminId_fkey" FOREIGN KEY ("createdByAdminId") REFERENCES public."AdminUser"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payment Payment_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RolePermission RolePermission_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public."Permission"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RolePermission RolePermission_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServiceRequest ServiceRequest_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceRequest"
    ADD CONSTRAINT "ServiceRequest_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ServiceRequest ServiceRequest_vehicleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceRequest"
    ADD CONSTRAINT "ServiceRequest_vehicleId_fkey" FOREIGN KEY ("vehicleId") REFERENCES public."Vehicle"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockMovement StockMovement_inventoryItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_inventoryItemId_fkey" FOREIGN KEY ("inventoryItemId") REFERENCES public."InventoryItem"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Vehicle Vehicle_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vehicle"
    ADD CONSTRAINT "Vehicle_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkerAssignment WorkerAssignment_jobCardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkerAssignment"
    ADD CONSTRAINT "WorkerAssignment_jobCardId_fkey" FOREIGN KEY ("jobCardId") REFERENCES public."JobCard"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkerAssignment WorkerAssignment_workerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkerAssignment"
    ADD CONSTRAINT "WorkerAssignment_workerId_fkey" FOREIGN KEY ("workerId") REFERENCES public."Worker"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkerLeave WorkerLeave_workerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkerLeave"
    ADD CONSTRAINT "WorkerLeave_workerId_fkey" FOREIGN KEY ("workerId") REFERENCES public."Worker"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ActivityLog activity_log_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ActivityLog"
    ADD CONSTRAINT activity_log_actor_id_fkey FOREIGN KEY ("actorId") REFERENCES public."AdminUser"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 9eC8r8aTv3Ak82bSaF5Szx6VrMlq7FF6HAoxz1ELiHpugDzMuBA2gX1DRXtO41O

